# import streamlit as st


# def render_sidebar() -> str:
#     """Renders the main navigation sidebar and returns the selected page name."""
#     with st.sidebar:
#         st.image(
#             "https://img.icons8.com/color/96/artificial-intelligence.png",
#             width=70,
#         )
#         st.markdown("## Service Experts AI")
#         st.caption("Revenue Opportunity Intelligence Platform")
#         st.divider()

#         # Navigation Menu
#         page = st.radio(
#             "Navigation",
#             [
#                 "🏠 Home",
#                 "📝 Single Transcript",
#                 "📂 Batch Processing",
#                 "📊 Analytics Dashboard",
#                 "💼 Opportunity Intelligence",
#                 "🧠 Executive Command Center",
#                 "🔍 Audit Center",
#             ],
#         )

#         st.divider()

#         # Pipeline Status Badges
#         st.markdown("### AI Pipeline")
#         st.success("Cleaner: Active")
#         st.success("Intent Detector: Active")
#         st.success("Evidence Extractor: Active")

#         st.divider()

#         # Model Info
#         st.markdown("### Loaded Models")
#         st.info("Claude 3.5 Sonnet\nSemantic Vector Search\nBusiness Rule Engine")

#         st.divider()

#         # Session Dataset Status
#         st.markdown("### Current Dataset")
#         uploaded_df = st.session_state.get("uploaded_df")
#         if uploaded_df is None:
#             st.metric("Loaded Rows", "None")
#         else:
#             st.metric("Loaded Rows", f"{len(uploaded_df):,}")

#         if st.session_state.get("run_complete"):
#             st.success("Batch Analysis Finished")
#         else:
#             st.caption("No batch active")

#         return page


###################################===============================================================###################################

import streamlit as st


def render_sidebar() -> str:
    """Renders the main navigation sidebar and returns the selected page name."""
    
    # ❌ Hides Streamlit's default native page navigation list (app, audit, batch, etc.)
    st.markdown(
        """
        <style>
            [data-testid="stSidebarNav"] {
                display: none !important;
            }
        </style>
        """,
        unsafe_allow_html=True,
    )

    with st.sidebar:
        st.image(
            "https://img.icons8.com/color/96/artificial-intelligence.png",
            width=70,
        )
        st.markdown("## Service Experts AI")
        st.caption("Revenue Opportunity Intelligence Platform")
        st.divider()

        # Navigation Menu
        page = st.radio(
            "Navigation",
            [
                "🏠 Home",
                "📝 Single Transcript",
                "📂 Batch Processing",
                "📊 Analytics Dashboard",
                "💼 Opportunity Intelligence",
                "🧠 Executive Command Center",
                "🔍 Audit Center",
            ],
        )

        st.divider()

        # Pipeline Status Badges
        st.markdown("### AI Pipeline")
        st.success("Cleaner: Active")
        st.success("Intent Detector: Active")
        st.success("Evidence Extractor: Active")

        st.divider()

        # Model Info
        st.markdown("### Loaded Models")
        st.info("Claude 3.5 Sonnet\nSemantic Vector Search\nBusiness Rule Engine")

        return page