import pandas as pd
import streamlit as st


def render_kpi_cards(df: pd.DataFrame):
    """Renders standard top-level metric card row."""
    total_calls = len(df)
    revenue_calls = int(df["revenue_opportunity"].sum()) if "revenue_opportunity" in df.columns else 0
    revenue_pct = round((revenue_calls / max(total_calls, 1)) * 100, 1)
    avg_conf = round(df["confidence_score"].mean(), 1) if "confidence_score" in df.columns else 0
    appts = (df["appointment_status"] == "Requested").sum() if "appointment_status" in df.columns else 0

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Total Calls", f"{total_calls:,}")
    c2.metric("Revenue Opportunities", revenue_calls)
    c3.metric("Revenue Opportunity %", f"{revenue_pct}%")
    c4.metric("Avg Model Confidence", f"{avg_conf}%")
    c5.metric("Appointments Requested", appts)


def render_executive_summary_card(df: pd.DataFrame):
    """Renders a formatted AI Executive Summary banner."""
    total_calls = len(df)
    revenue_calls = int(df["revenue_opportunity"].sum()) if "revenue_opportunity" in df.columns else 0
    revenue_pct = round((revenue_calls / max(total_calls, 1)) * 100, 1)

    top_trade = df["trade"].mode()[0] if "trade" in df.columns and not df["trade"].empty else "N/A"
    top_service = (
        df["requested_service"].mode()[0]
        if "requested_service" in df.columns and not df["requested_service"].empty
        else "N/A"
    )

    st.success(
        f"""
### 💡 Executive Intelligence Summary
Processed **{total_calls:,}** customer calls.

* **Revenue Opportunities Detected:** {revenue_calls} ({revenue_pct}%)
* **Top Trade Category:** {top_trade}
* **Most Requested Service:** {top_service}
"""
    )


def render_health_score_card(score: int):
    """Renders business health score metric with dynamic color status."""
    c1, c2 = st.columns([1, 2])
    with c1:
        st.metric("Business Health Index", f"{score} / 100")

    with c2:
        if score >= 85:
            st.success("🟢 **Status:** Optimal operational performance.")
        elif score >= 70:
            st.info("🟡 **Status:** Healthy with minor conversion leaks.")
        else:
            st.warning("🔴 **Status:** Attention Required. High opportunity leakage detected.")