import pandas as pd
import streamlit as st


def render_dashboard_filters(df: pd.DataFrame) -> pd.DataFrame:
    """Renders standard multi-select filters and returns the filtered DataFrame."""
    st.subheader("Filter Dataset")
    c1, c2, c3, c4 = st.columns(4)

    filtered_df = df.copy()

    # 1. Trade Filter
    if "trade" in df.columns:
        trades = sorted(df["trade"].dropna().unique())
        with c1:
            selected_trades = st.multiselect("Trade", trades, default=trades)
            filtered_df = filtered_df[filtered_df["trade"].isin(selected_trades)]

    # 2. Urgency Filter
    if "urgency" in df.columns:
        urgencies = sorted(df["urgency"].dropna().unique())
        with c2:
            selected_urgency = st.multiselect("Urgency", urgencies, default=urgencies)
            filtered_df = filtered_df[filtered_df["urgency"].isin(selected_urgency)]

    # 3. Revenue Filter
    if "revenue_opportunity" in df.columns:
        with c3:
            selected_revenue = st.multiselect(
                "Revenue Opportunity", [True, False], default=[True, False]
            )
            filtered_df = filtered_df[filtered_df["revenue_opportunity"].isin(selected_revenue)]

    # 4. Appointment Status Filter
    if "appointment_status" in df.columns:
        appts = sorted(df["appointment_status"].dropna().unique())
        with c4:
            selected_appts = st.multiselect("Appointment Status", appts, default=appts)
            filtered_df = filtered_df[filtered_df["appointment_status"].isin(selected_appts)]

    return filtered_df


def render_opportunity_filters(df: pd.DataFrame) -> pd.DataFrame:
    """Renders advanced filters tailored for the Opportunity Intelligence center."""
    c1, c2, c3 = st.columns(3)
    filtered_df = df.copy()

    with c1:
        min_confidence = st.slider("Minimum Confidence Threshold", 0, 100, 50)
        if "confidence_score" in filtered_df.columns:
            filtered_df = filtered_df[filtered_df["confidence_score"] >= min_confidence]

    with c2:
        revenue_only = st.checkbox("Revenue Opportunities Only", value=True)
        if revenue_only and "revenue_opportunity" in filtered_df.columns:
            filtered_df = filtered_df[filtered_df["revenue_opportunity"] == True]

    with c3:
        if "pricing_discussed" in df.columns:
            pricing_only = st.checkbox("Pricing Discussed Only", value=False)
            if pricing_only:
                filtered_df = filtered_df[filtered_df["pricing_discussed"] == True]

    return filtered_df