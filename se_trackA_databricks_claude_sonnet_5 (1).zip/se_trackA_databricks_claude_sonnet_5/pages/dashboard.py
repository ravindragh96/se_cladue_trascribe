import pandas as pd
import plotly.express as px
import streamlit as st


def render_dashboard_page():
    st.title("📊 Executive Analytics Dashboard")
    st.caption("Aggregated intelligence from processed customer conversations.")

    if st.session_state.get("batch_results") is None:
        st.warning("⚠️ No batch analysis results found. Please run Batch Processing first.")
        return

    df = st.session_state["batch_results"].copy()

    # --- FILTERS ---
    st.subheader("Filters")
    c1, c2, c3, c4 = st.columns(4)

    trades = sorted(df["trade"].dropna().unique()) if "trade" in df.columns else []
    urgencies = sorted(df["urgency"].dropna().unique()) if "urgency" in df.columns else []
    appts = sorted(df["appointment_status"].dropna().unique()) if "appointment_status" in df.columns else []

    with c1:
        selected_trade = st.multiselect("Trade", trades, default=trades)
    with c2:
        selected_urgency = st.multiselect("Urgency", urgencies, default=urgencies)
    with c3:
        selected_revenue = st.multiselect("Revenue Opportunity", [True, False], default=[True, False])
    with c4:
        selected_appt = st.multiselect("Appointment Status", appts, default=appts)

    # Apply Filters Safely
    if trades:
        df = df[df["trade"].isin(selected_trade)]
    if urgencies:
        df = df[df["urgency"].isin(selected_urgency)]
    if "revenue_opportunity" in df.columns:
        df = df[df["revenue_opportunity"].isin(selected_revenue)]
    if appts:
        df = df[df["appointment_status"].isin(selected_appt)]

    if df.empty:
        st.info("No data matching the selected filter criteria.")
        return

    # --- KPI METRICS ---
    total_calls = len(df)
    revenue_calls = int(df["revenue_opportunity"].sum()) if "revenue_opportunity" in df.columns else 0
    revenue_pct = round((revenue_calls / total_calls) * 100, 1) if total_calls > 0 else 0
    avg_conf = round(df["confidence_score"].mean(), 1) if "confidence_score" in df.columns else 0
    requested_appts = (df["appointment_status"] == "Requested").sum() if "appointment_status" in df.columns else 0

    st.divider()
    r1 = st.columns(5)
    r1[0].metric("Total Calls", f"{total_calls:,}")
    r1[1].metric("Revenue Calls", revenue_calls)
    r1[2].metric("Revenue Rate", f"{revenue_pct}%")
    r1[3].metric("Avg Confidence", f"{avg_conf}%")
    r1[4].metric("Appointments Requested", requested_appts)

    st.divider()

    # --- VISUALIZATIONS ---
    col1, col2 = st.columns(2)

    with col1:
        if "revenue_opportunity" in df.columns:
            fig_rev = px.pie(
                df,
                names="revenue_opportunity",
                title="Revenue Opportunity Split",
                color_discrete_sequence=px.colors.qualitative.Pastel,
            )
            st.plotly_chart(fig_rev, use_container_width=True)

        if "service_category" in df.columns:
            fig_service = px.bar(
                df["service_category"].value_counts().reset_index(),
                x="service_category",
                y="count",
                title="Service Categories Breakdown",
            )
            st.plotly_chart(fig_service, use_container_width=True)

    with col2:
        if "appointment_status" in df.columns:
            fig_appt = px.pie(
                df,
                names="appointment_status",
                title="Appointment Request Status",
                color_discrete_sequence=px.colors.qualitative.Set2,
            )
            st.plotly_chart(fig_appt, use_container_width=True)

        if "confidence_score" in df.columns:
            fig_conf = px.histogram(
                df,
                x="confidence_score",
                nbins=20,
                title="AI Confidence Score Distribution",
            )
            st.plotly_chart(fig_conf, use_container_width=True)

    # Table View for Opportunity Inspection
    st.subheader("Revenue Opportunities Detail")
    if "revenue_opportunity" in df.columns:
        opp_df = df[df["revenue_opportunity"] == True]
        display_cols = [c for c in ["core_intent", "trade", "requested_service", "appointment_status", "confidence_score"] if c in opp_df.columns]
        st.dataframe(opp_df[display_cols], use_container_width=True)