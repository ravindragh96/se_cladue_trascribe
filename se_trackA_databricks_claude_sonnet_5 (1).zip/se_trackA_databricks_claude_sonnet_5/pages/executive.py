import pandas as pd
import plotly.express as px
import streamlit as st


def render_executive_page():
    st.title("🧠 Executive Command Center")
    st.caption("High-level strategic briefing and health scoring.")

    if st.session_state.get("batch_results") is None:
        st.warning("⚠️ Please run Batch Processing first.")
        return

    df = st.session_state["batch_results"].copy()

    # --- BUSINESS HEALTH SCORE FORMULA ---
    rev_rate = df["revenue_opportunity"].mean() if "revenue_opportunity" in df.columns else 0
    appt_rate = (df["appointment_status"] == "Requested").mean() if "appointment_status" in df.columns else 0
    conf_rate = (df["confidence_score"].mean() / 100) if "confidence_score" in df.columns else 0

    # Avg Intent Score (intent_strength is 1-10 scale)
    avg_intent = round(df["intent_strength"].mean(), 1) if "intent_strength" in df.columns else 0

    # Weighted composite score equation
    health_score = round((rev_rate * 0.45 + appt_rate * 0.30 + conf_rate * 0.25) * 100)

    st.subheader("Overall Business Health Index")
    c1, c2 = st.columns([1, 3])

    with c1:
        st.metric("Avg Intent Score", f"{avg_intent} / 10")
        if avg_intent >= 7:
            st.success("High Conversion Potential")
        elif avg_intent >= 4:
            st.info("Moderate Conversion Potential")
        else:
            st.warning("Low Conversion Potential")

    with c2:
        st.markdown(f"""
        ### Executive Synthesis
        * Processed **{len(df):,}** call transcripts.
        * Identified **{int(df['revenue_opportunity'].sum())}** high-intent revenue opportunities.
        * Mean model detection confidence stands at **{round(df['confidence_score'].mean(), 1)}%**.
        """)

    st.divider()

    # --- HEATMAP ANALYSIS ---
    if "trade" in df.columns and "urgency" in df.columns:
        st.subheader("Call Density Heatmap (Trade vs. Urgency)")
        heat_df = df.groupby(["trade", "urgency"]).size().reset_index(name="Volume")
        fig_heat = px.density_heatmap(
            heat_df, x="trade", y="urgency", z="Volume", color_continuous_scale="Viridis"
        )
        st.plotly_chart(fig_heat, use_container_width=True)

    # --- PRIORITY CALLS QUEUE ---
    st.subheader("🔥 High Priority / Escalation Queue")
    priority_df = df[
        (df.get("urgency") == "emergency") | (df.get("confidence_score", 0) >= 90)
    ]
    st.dataframe(priority_df, use_container_width=True)

    # --- REPORT EXPORT ---
    st.divider()
    summary_text = f"""SERVICE EXPERTS AI - EXECUTIVE BRIEF
--------------------------------------------------
Total Calls Analyzed: {len(df)}
Business Health Index: {health_score}/100
Revenue Opportunities: {int(df['revenue_opportunity'].sum())}
Mean Confidence: {round(df['confidence_score'].mean(), 1)}%
--------------------------------------------------
"""
    st.download_button("📥 Download Briefing Document", summary_text, file_name="executive_summary.txt")