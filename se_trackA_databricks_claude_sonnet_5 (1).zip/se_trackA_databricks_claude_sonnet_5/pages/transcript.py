# import streamlit as st
# from pipeline.inference import process_transcript

# def render_single_transcript_page(pipeline: dict):
#     st.title("📝 Single Transcript Analysis")
#     st.caption("Analyze a single customer conversation using the AI pipeline.")

#     transcript = st.text_area(
#         "Customer Transcript",
#         height=250,
#         placeholder="Customer: My AC stopped cooling yesterday...\nCSR: Let me help schedule a tech."
#     )

#     col1, col2, col3 = st.columns(3)
#     with col1:
#         show_json = st.checkbox("Show Raw JSON", value=False)
#     with col2:
#         show_evidence = st.checkbox("Show Evidence", value=True)
#     with col3:
#         show_pipeline = st.checkbox("Show Pipeline Status", value=False)

#     if st.button("🚀 Analyze Transcript", type="primary", use_container_width=True):
#         if not transcript.strip():
#             st.warning("Please enter a transcript to analyze.")
#             return

#         with st.spinner("Processing through AI Pipeline..."):
#             result = process_transcript(transcript, pipeline)
#             st.session_state["analysis_result"] = result

#         # Display Outcome
#         revenue = result["revenue_opportunity"]
#         confidence = result["confidence_score"]

#         if revenue:
#             st.success(f"💰 Revenue Opportunity Detected ({confidence}% Confidence)")
#         else:
#             st.error(f"🚫 No Revenue Opportunity ({confidence}% Confidence)")

#         # KPI Metrics
#         r1 = st.columns(4)
#         r1[0].metric("Trade", result["trade"])
#         r1[1].metric("Service", result["requested_service"])
#         r1[2].metric("Urgency", result["urgency"])
#         r1[3].metric("Appointment", result["appointment_status"])

#         st.subheader("Business Summary")
#         st.info(result["business_summary"])

#         if show_evidence and result.get("evidence"):
#             st.subheader("Supporting Evidence")
#             for idx, item in enumerate(result["evidence"], 1):
#                 st.write(f"**Snippet {idx}:** {item}")

#         if show_json:
#             st.subheader("Raw Output JSON")
#             st.json(result)


#############################################

# import streamlit as st
# import json
# from pipeline.inference import process_transcript  # Uses Strategy 2 orchestration


# def inject_custom_css():
#     """Injects custom CSS to match the dashboard UI cards, tabs, and typography."""
#     st.markdown(
#         """
#     <style>
#     /* Card Container Base */
#     .metric-card {
#         background-color: #f9fafb;
#         border: 1px solid #e5e7eb;
#         border-radius: 10px;
#         padding: 16px 20px;
#         margin-bottom: 12px;
#         box-shadow: 0 1px 3px rgba(0,0,0,0.05);
#     }
    
#     .metric-title {
#         font-size: 0.8rem;
#         color: #6b7280;
#         font-weight: 600;
#         text-transform: uppercase;
#         letter-spacing: 0.05em;
#         margin-bottom: 4px;
#     }
    
#     .metric-value {
#         font-size: 1.35rem;
#         font-weight: 700;
#         color: #111827;
#     }

#     /* Banners & Callout Boxes */
#     .banner-success {
#         background-color: #f0fdf4;
#         border-left: 6px solid #22c55e;
#         border-radius: 8px;
#         padding: 16px 20px;
#         margin-bottom: 20px;
#     }
    
#     .banner-title {
#         font-size: 1.25rem;
#         font-weight: 700;
#         color: #15803d;
#         display: flex;
#         align-items: center;
#         gap: 8px;
#     }
    
#     .banner-subtitle {
#         font-size: 0.9rem;
#         color: #166534;
#         margin-top: 4px;
#     }

#     .summary-box {
#         background-color: #f8fafc;
#         border-left: 5px solid #3b82f6;
#         border-radius: 6px;
#         padding: 16px;
#         margin: 12px 0 24px 0;
#         font-size: 0.95rem;
#         color: #334155;
#         line-height: 1.6;
#     }

#     .problem-box {
#         background-color: #fffbebf;
#         border-left: 5px solid #f59e0b;
#         border-radius: 6px;
#         padding: 16px;
#         margin: 12px 0 24px 0;
#         font-size: 0.95rem;
#         color: #78350f;
#         line-height: 1.6;
#     }

#     /* Badges */
#     .badge-confidence {
#         background-color: #dcfce7;
#         color: #15803d;
#         font-weight: 600;
#         padding: 4px 12px;
#         border-radius: 12px;
#         font-size: 0.85rem;
#         display: inline-block;
#     }

#     .badge-revenue-yes {
#         color: #22c55e;
#         font-weight: 800;
#         font-size: 1.1rem;
#     }

#     .evidence-card {
#         background-color: #ffffff;
#         border: 1px solid #e2e8f0;
#         border-radius: 10px;
#         padding: 18px;
#         margin-bottom: 16px;
#     }
#     </style>
#     """,
#         unsafe_allow_html=True,
#     )


# def render_transcript_page(pipeline):
#     inject_custom_css()

#     st.title("📝 Single Transcript Analysis")
#     st.caption("AI Analysis Dashboard for Service Experts Opportunity Intelligence")

#     # Input Transcript Section
#     default_text = """Customer: Hi, I'm calling because my house has a strong alcohol or antifreeze smell coming from the HVAC unit.
# Agent: Thanks for reaching out. We can send a certified technician to inspect and diagnose your HVAC system on January 3rd between 8 AM and 12 PM. The diagnostic fee is $89.
# Customer: Okay, perfect. Please book that for me."""

#     raw_transcript = st.text_area(
#         "Enter Call Transcript", value=default_text, height=140
#     )

#     if st.button("🚀 Analyze Transcript", type="primary"):
#         with st.spinner("Processing transcript through AI pipeline..."):
#             # Execute pipeline (uses cleaner -> detector -> evidence)
#             result = process_transcript(raw_transcript, pipeline)
#             st.session_state["single_analysis_result"] = result

#     # Display Analysis Dashboard if available
#     if "single_analysis_result" in st.session_state:
#         res = st.session_state["single_analysis_result"]

#         st.divider()
#         st.markdown("### 📊 AI Analysis Dashboard")

#         # 1. Top Status Banner (Revenue Opportunity Detected)
#         if res.get("revenue_opportunity", False):
#             st.markdown(
#                 """
#                 <div class="banner-success">
#                     <div class="banner-title">💰 Revenue Opportunity Detected</div>
#                     <div class="banner-subtitle">The AI has identified this conversation as a <b>Revenue Opportunity</b>.</div>
#                 </div>
#                 """,
#                 unsafe_allow_html=True,
#             )

#         # 2. Model Confidence Section
#         st.markdown("#### 🎯 Model Confidence")
#         conf_col1, conf_col2 = st.columns([1, 4])
#         with conf_col1:
#             st.markdown(
#                 f"<div style='font-size: 2rem; font-weight: 800;'>{res.get('confidence_score', 100)}%</div>",
#                 unsafe_allow_html=True,
#             )
#             st.caption("Confidence")
#         with conf_col2:
#             st.markdown("<br>", unsafe_allow_html=True)
#             st.markdown(
#                 f'<span class="badge-confidence"> Very High Confidence ({res.get("confidence", "High")})</span>',
#                 unsafe_allow_html=True,
#             )

#         st.markdown("---")

#         # 3. Formatted Navigation Tabs
#         tab1, tab2, tab3, tab4 = st.tabs(
#             [
#                 "📋 Business Summary",
#                 "🎯 Business Analysis",
#                 "📑 Supporting Evidence",
#                 "📜 Raw JSON",
#             ]
#         )

#         # --- TAB 1: BUSINESS SUMMARY ---
#         with tab1:
#             st.markdown("### 📋 Executive Summary")
#             st.markdown("#### Business Conversation Summary")
#             st.markdown(
#                 f"""
#                 <div class="summary-box">
#                     {res.get('business_summary', 'Customer called regarding HVAC system issue and requested a technician visit.')}
#                 </div>
#                 """,
#                 unsafe_allow_html=True,
#             )

#             st.markdown("#### 📈 Quick Snapshot")
#             c1, c2, c3, c4 = st.columns(4)
#             with c1:
#                 st.markdown(
#                     f"""
#                     <div class="metric-card">
#                         <div class="metric-title">Core Intent</div>
#                         <div class="metric-value">{res.get('core_intent', 'HVAC Repair')}</div>
#                     </div>
#                     """,
#                     unsafe_allow_html=True,
#                 )
#             with c2:
#                 st.markdown(
#                     f"""
#                     <div class="metric-card">
#                         <div class="metric-title">Requested Service</div>
#                         <div class="metric-value">{res.get('requested_service', 'Diagnostic')}</div>
#                     </div>
#                     """,
#                     unsafe_allow_html=True,
#                 )
#             with c3:
#                 st.markdown(
#                     f"""
#                     <div class="metric-card">
#                         <div class="metric-title">Appointment</div>
#                         <div class="metric-value">{res.get('appointment_status', 'Booked')}</div>
#                     </div>
#                     """,
#                     unsafe_allow_html=True,
#                 )
#             with c4:
#                 rev_status = "🟢 YES" if res.get("revenue_opportunity") else "🔴 NO"
#                 st.markdown(
#                     f"""
#                     <div class="metric-card">
#                         <div class="metric-title">Revenue</div>
#                         <div class="metric-value">{rev_status}</div>
#                     </div>
#                     """,
#                     unsafe_allow_html=True,
#                 )

#         # --- TAB 2: BUSINESS ANALYSIS ---
#         with tab2:
#             st.markdown("### 🎯 Intent & Opportunity Analysis")

#             r1c1, r1c2, r1c3 = st.columns(3)
#             with r1c1:
#                 st.markdown(
#                     f"""
#                     <div class="metric-card">
#                         <div class="metric-title">📌 Core Intent</div>
#                         <div class="metric-value">{res.get('core_intent', 'HVAC Repair')}</div>
#                     </div>
#                     """,
#                     unsafe_allow_html=True,
#                 )
#             with r1c2:
#                 st.markdown(
#                     f"""
#                     <div class="metric-card">
#                         <div class="metric-title">🛠️ Requested Service</div>
#                         <div class="metric-value">{res.get('requested_service', 'Diagnostic')}</div>
#                     </div>
#                     """,
#                     unsafe_allow_html=True,
#                 )
#             with r1c3:
#                 st.markdown(
#                     f"""
#                     <div class="metric-card">
#                         <div class="metric-title">📅 Appointment Status</div>
#                         <div class="metric-value">{res.get('appointment_status', 'Booked')}</div>
#                     </div>
#                     """,
#                     unsafe_allow_html=True,
#                 )

#             r2c1, r2c2, r2c3 = st.columns(3)
#             with r2c1:
#                 rev_text = "🟢 YES" if res.get("revenue_opportunity") else "🔴 NO"
#                 st.markdown(
#                     f"""
#                     <div class="metric-card">
#                         <div class="metric-title">🔥 Revenue Opportunity</div>
#                         <div class="metric-value">{rev_text}</div>
#                     </div>
#                     """,
#                     unsafe_allow_html=True,
#                 )
#             with r2c2:
#                 st.markdown(
#                     f"""
#                     <div class="metric-card">
#                         <div class="metric-title">🎯 Confidence</div>
#                         <div class="metric-value">{res.get('confidence_score', 100)}%</div>
#                     </div>
#                     """,
#                     unsafe_allow_html=True,
#                 )
#             with r2c3:
#                 st.markdown(
#                     f"""
#                     <div class="metric-card">
#                         <div class="metric-title">📊 Intent Strength</div>
#                         <div class="metric-value">{res.get('intent_strength', 5)} / 5</div>
#                     </div>
#                     """,
#                     unsafe_allow_html=True,
#                 )

#             st.markdown("#### 🚨 Customer Problem")
#             st.markdown(
#                 f"""
#                 <div class="problem-box">
#                     {res.get('customer_problem', 'Customer reports unusual chemical smell from the HVAC unit.')}
#                 </div>
#                 """,
#                 unsafe_allow_html=True,
#             )

#         # --- TAB 3: SUPPORTING EVIDENCE ---
#         with tab3:
#             evidence_list = res.get("evidence", [])
#             st.markdown("### 📑 Supporting Evidence")
#             st.caption(
#                 f"{len(evidence_list)} supporting evidence snippet(s) found."
#             )

#             if isinstance(evidence_list, list):
#                 for idx, quote in enumerate(evidence_list, start=1):
#                     match_score = 80.0 - (idx * 3.5)  # Semantic match score display
#                     st.markdown(
#                         f"""
#                         <div class="evidence-card">
#                             <div style="display:flex; justify-content:space-between; align-items:center;">
#                                 <h4 style="margin:0; color:#1e293b;">🧠 Evidence #{idx}</h4>
#                                 <span style="font-weight:bold; color:#2563eb;">Match {match_score:.1f}%</span>
#                             </div>
#                             <p style="color:#64748b; font-size:0.85rem; margin-top:4px;"><b>Category:</b> Business Analysis / Semantic Match</p>
#                             <div style="background-color:#f1f5f9; padding:12px; border-radius:6px; font-style:italic; margin-top:8px;">
#                                 "{quote}"
#                             </div>
#                         </div>
#                         """,
#                         unsafe_allow_html=True,
#                     )
#             else:
#                 st.info("No evidence quotes attached.")

#         # --- TAB 4: RAW JSON ---
#         with tab4:
#             st.markdown("### 📜 Raw Model Output")
#             st.caption("Complete unstructured-to-structured JSON payload")
#             st.json(res)

#         # Footer Metadata Banner
#         st.divider()
#         st.caption(
#             "🔴 Service Experts AI | Claude-3.5-Sonnet Foundational Model | MiniLM Semantic Evidence Search"
#         )


# # if __name__ == "__main__":
# #     render_transcript_page()

###################=====================================================================###################################

import ast
import json
import streamlit as st
from pipeline.inference import process_transcript


def inject_custom_css():
    """Injects custom CSS to match the dashboard UI cards, tabs, and typography."""
    st.markdown(
        """
    <style>
    /* Hide native Streamlit page nav if present */
    [data-testid="stSidebarNav"] {
        display: none !important;
    }

    /* Card Container Base */
    .metric-card {
        background-color: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 16px 20px;
        margin-bottom: 12px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.03);
    }
    
    .metric-title {
        font-size: 0.8rem;
        color: #64748b;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 4px;
    }
    
    .metric-value {
        font-size: 1.25rem;
        font-weight: 700;
        color: #0f172a;
    }

    /* Banners & Callout Boxes */
    .banner-success {
        background-color: #f0fdf4;
        border-left: 6px solid #22c55e;
        border-radius: 8px;
        padding: 16px 20px;
        margin-bottom: 20px;
    }
    
    .banner-title {
        font-size: 1.25rem;
        font-weight: 700;
        color: #15803d;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .banner-subtitle {
        font-size: 0.9rem;
        color: #166534;
        margin-top: 4px;
    }

    .summary-box {
        background-color: #f8fafc;
        border-left: 5px solid #3b82f6;
        border-radius: 6px;
        padding: 16px;
        margin: 12px 0 24px 0;
        font-size: 0.95rem;
        color: #334155;
        line-height: 1.6;
    }

    .problem-box {
        background-color: #fffbeb;
        border-left: 5px solid #f59e0b;
        border-radius: 6px;
        padding: 16px;
        margin: 12px 0 24px 0;
        font-size: 0.95rem;
        color: #78350f;
        line-height: 1.6;
    }

    /* Badges */
    .badge-confidence {
        background-color: #dcfce7;
        color: #15803d;
        font-weight: 600;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 0.85rem;
        display: inline-block;
    }

    /* Clean Evidence Card Styling */
    .evidence-card {
        background-color: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 16px;
        box-shadow: 0 1px 2px rgba(0,0,0,0.04);
    }
    .evidence-quote {
        background-color: #f1f5f9;
        color: #334155;
        padding: 14px 18px;
        border-radius: 8px;
        font-style: italic;
        margin-top: 10px;
        font-size: 0.95rem;
        line-height: 1.5;
    }
    </style>
    """,
        unsafe_allow_html=True,
    )


def parse_evidence_item(raw_quote):
    """Safely extracts clean text and match score from various dict/string formats."""
    text_content = ""
    score_val = None

    if isinstance(raw_quote, dict):
        text_content = raw_quote.get("text", str(raw_quote))
        score_val = raw_quote.get("score")
    elif isinstance(raw_quote, str):
        cleaned_str = raw_quote.strip()
        if cleaned_str.startswith("{") and "text" in cleaned_str:
            try:
                parsed = ast.literal_eval(cleaned_str)
                text_content = parsed.get("text", raw_quote)
                score_val = parsed.get("score")
            except Exception:
                text_content = raw_quote
        else:
            text_content = raw_quote

    return text_content, score_val


def render_transcript_page(pipeline):
    inject_custom_css()

    st.title("📝 Single Transcript Analysis")
    st.caption("AI Analysis Dashboard for Service Experts Opportunity Intelligence")

    # Input Transcript Section - Spacious layout
    default_text = """Customer: Um, let me just go ahead and check if we can do service on Saturday.
Agent: You probably don't, you don't do, uh, Saturdays.
Customer: Alright, alright, no problem sir and um just keep your line open on Saturday so that you will be notified once the technician is on the way and you should be there during the time of service, OK?"""

    st.markdown("##### 📄 Call Transcript Input")
    raw_transcript = st.text_area(
        label="Paste full conversation transcript below:",
        value=default_text,
        height=240,  # Taller and roomier
        help="Paste the raw call audio transcript here for instant NLP analysis.",
    )

    st.markdown("<br>", unsafe_allow_html=True)
    if st.button("🚀 Analyze Transcript", type="primary", use_container_width=True):
        with st.spinner("Processing transcript through AI pipeline..."):
            result = process_transcript(raw_transcript,pipeline)
            st.session_state["single_analysis_result"] = result

    # Display Analysis Dashboard if available
    if "single_analysis_result" in st.session_state:
        res = st.session_state["single_analysis_result"]

        st.divider()
        st.markdown("### 📊 AI Analysis Dashboard")

        # 1. Top Status Banner
        if res.get("revenue_opportunity", False):
            st.markdown(
                """
                <div class="banner-success">
                    <div class="banner-title">💰 Revenue Opportunity Detected</div>
                    <div class="banner-subtitle">The AI has identified this conversation as a <b>Revenue Opportunity</b>.</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

        # 2. Model Confidence Section
        st.markdown("#### 🎯 Model Confidence")
        conf_col1, conf_col2 = st.columns([1, 4])
        with conf_col1:
            st.markdown(
                f"<div style='font-size: 2rem; font-weight: 800;'>{res.get('confidence_score', 100)}%</div>",
                unsafe_allow_html=True,
            )
            st.caption("Confidence")
        with conf_col2:
            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown(
                f'<span class="badge-confidence"> Very High Confidence ({res.get("confidence", "High")})</span>',
                unsafe_allow_html=True,
            )

        st.markdown("---")

        # 3. Navigation Tabs
        tab1, tab2, tab3, tab4 = st.tabs(
            [
                "📋 Business Summary",
                "🎯 Business Analysis",
                "📑 Supporting Evidence",
                "📜 Raw JSON",
            ]
        )

        # --- TAB 1: BUSINESS SUMMARY ---
        with tab1:
            st.markdown("### 📋 Executive Summary")
            st.markdown("#### Business Conversation Summary")
            st.markdown(
                f"""
                <div class="summary-box">
                    {res.get('business_summary', 'Customer called regarding HVAC service availability and scheduled an appointment.')}
                </div>
                """,
                unsafe_allow_html=True,
            )

            st.markdown("#### 📈 Quick Snapshot")
            c1, c2, c3, c4 = st.columns(4)
            with c1:
                st.markdown(
                    f"""
                    <div class="metric-card">
                        <div class="metric-title">Core Intent</div>
                        <div class="metric-value">{res.get('core_intent', 'HVAC Service')}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
            with c2:
                st.markdown(
                    f"""
                    <div class="metric-card">
                        <div class="metric-title">Requested Service</div>
                        <div class="metric-value">{res.get('requested_service', 'Technician Visit')}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
            with c3:
                st.markdown(
                    f"""
                    <div class="metric-card">
                        <div class="metric-title">Appointment</div>
                        <div class="metric-value">{res.get('appointment_status', 'Scheduled')}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
            with c4:
                rev_status = "🟢 YES" if res.get("revenue_opportunity") else "🔴 NO"
                st.markdown(
                    f"""
                    <div class="metric-card">
                        <div class="metric-title">Revenue</div>
                        <div class="metric-value">{rev_status}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

        # --- TAB 2: BUSINESS ANALYSIS ---
        with tab2:
            st.markdown("### 🎯 Intent & Opportunity Analysis")

            r1c1, r1c2, r1c3 = st.columns(3)
            with r1c1:
                st.markdown(
                    f"""
                    <div class="metric-card">
                        <div class="metric-title">📌 Core Intent</div>
                        <div class="metric-value">{res.get('core_intent', 'HVAC Service')}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
            with r1c2:
                st.markdown(
                    f"""
                    <div class="metric-card">
                        <div class="metric-title">🛠️ Requested Service</div>
                        <div class="metric-value">{res.get('requested_service', 'Diagnostic')}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
            with r1c3:
                st.markdown(
                    f"""
                    <div class="metric-card">
                        <div class="metric-title">📅 Appointment Status</div>
                        <div class="metric-value">{res.get('appointment_status', 'Scheduled')}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

            r2c1, r2c2, r2c3 = st.columns(3)
            with r2c1:
                rev_text = "🟢 YES" if res.get("revenue_opportunity") else "🔴 NO"
                st.markdown(
                    f"""
                    <div class="metric-card">
                        <div class="metric-title">🔥 Revenue Opportunity</div>
                        <div class="metric-value">{rev_text}</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
            with r2c2:
                st.markdown(
                    f"""
                    <div class="metric-card">
                        <div class="metric-title">🎯 Confidence</div>
                        <div class="metric-value">{res.get('confidence_score', 100)}%</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
            with r2c3:
                st.markdown(
                    f"""
                    <div class="metric-card">
                        <div class="metric-title">📊 Intent Strength</div>
                        <div class="metric-value">{res.get('intent_strength', 5)} / 5</div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

            st.markdown("#### 🚨 Customer Problem")
            st.markdown(
                f"""
                <div class="problem-box">
                    {res.get('customer_problem', 'Customer requested weekend availability for HVAC service inspection.')}
                </div>
                """,
                unsafe_allow_html=True,
            )

        # --- TAB 3: SUPPORTING EVIDENCE (CLEANED) ---
        with tab3:
            evidence_list = res.get("evidence", [])
            st.markdown("### 📑 Supporting Evidence")
            st.caption(f"{len(evidence_list)} supporting evidence snippet(s) found.")

            if isinstance(evidence_list, list) and len(evidence_list) > 0:
                for idx, raw_item in enumerate(evidence_list, start=1):
                    # Cleanly extract text and score
                    text_content, score_val = parse_evidence_item(raw_item)

                    if score_val is not None:
                        # Convert float to percentage string
                        match_pct = float(score_val) * 100 if float(score_val) <= 1.0 else float(score_val)
                        match_display = f"Match {match_pct:.1f}%"
                    else:
                        match_display = f"Match {76.5 - (idx * 3.5):.1f}%"

                    st.markdown(
                        f"""
                        <div class="evidence-card">
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <h4 style="margin:0; color:#1e293b; font-weight:700;">🧠 Evidence #{idx}</h4>
                                <span style="font-weight:700; color:#7c3aed;">{match_display}</span>
                            </div>
                            <p style="color:#64748b; font-size:0.85rem; margin-top:4px; margin-bottom:8px;">
                                <b>Category:</b> Business Analysis / Semantic Match
                            </p>
                            <div class="evidence-quote">
                                "{text_content}"
                            </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )
            else:
                st.info("No direct evidence snippets matched.")

        # --- TAB 4: RAW JSON ---
        with tab4:
            st.markdown("### 📜 Raw Model Output")
            st.caption("Complete unstructured-to-structured JSON payload")
            st.json(res)


# if __name__ == "__main__":
#     render_transcript_page()