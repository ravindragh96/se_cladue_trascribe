import plotly.graph_objects as go
import streamlit as st


def render_audit_page():
    st.title("🔍 AI Explainability & Audit Center")
    st.caption("Inspect individual AI predictions, verify supporting quote evidence, and log feedback.")

    if st.session_state.get("batch_results") is None:
        st.warning("⚠️ Please run Batch Processing first.")
        return

    df = st.session_state["batch_results"]

    # --- SEARCH & RECORD SELECTION ---
    search_term = st.text_input("Search Calls (by Call ID or Problem Text)", placeholder="Type to filter...")

    filtered_df = df
    if search_term:
        filtered_df = df[
            df["customer_problem"].astype(str).str.contains(search_term, case=False, na=False)
            | df["business_summary"].astype(str).str.contains(search_term, case=False, na=False)
        ]

    if filtered_df.empty:
        st.info("No records matched your search.")
        return

    selected_index = st.selectbox("Select Call Index to Inspect", options=filtered_df.index)
    record = filtered_df.loc[selected_index]

    # --- INSPECTION LAYOUT ---
    c1, c2 = st.columns([2, 1])

    with c1:
        st.subheader("Business Summary")
        st.info(record.get("business_summary", "N/A"))

        st.subheader("AI Business Decision Reasoning")
        st.write(record.get("business_reason", "N/A"))

        st.subheader("Supporting Textual Evidence")
        evidence_list = record.get("evidence", [])
        if isinstance(evidence_list, list) and len(evidence_list) > 0:
            for idx, snippet in enumerate(evidence_list, 1):
                st.success(f"Quote {idx}: \"{snippet}\"")
        else:
            st.write("No specific textual evidence retrieved.")

    with c2:
        # Confidence Gauge
        conf = float(record.get("confidence_score", 0))
        fig_gauge = go.Figure(
            go.Indicator(
                mode="gauge+number",
                value=conf,
                title={"text": "AI Confidence Score"},
                gauge={"axis": {"range": [0, 100]}, "bar": {"color": "darkblue"}},
            )
        )
        st.plotly_chart(fig_gauge, use_container_width=True)

        st.markdown(f"**Trade:** {record.get('trade', 'N/A')}")
        st.markdown(f"**Urgency:** {record.get('urgency', 'N/A')}")
        st.markdown(f"**Revenue Opportunity:** {record.get('revenue_opportunity', 'N/A')}")

    # --- REVIEWER FEEDBACK MECHANISM ---
    st.divider()
    st.subheader("📝 Human Reviewer Audit Feedback")
    fb_col1, fb_col2 = st.columns([1, 2])

    with fb_col1:
        feedback_decision = st.radio("Is this AI prediction accurate?", ["Correct", "Incorrect", "Unsure"])
    with fb_col2:
        reviewer_notes = st.text_area("Reviewer Audit Notes", placeholder="Provide context if model output was incorrect...")

    if st.button("Submit Audit Feedback"):
        st.success(f"Feedback logged for record #{selected_index}! Decision: {feedback_decision}")