import pandas as pd
import plotly.express as px
import streamlit as st


def render_opportunity_page():
    st.title("💼 Opportunity Intelligence Center")
    st.caption("Conversion funnel analytics & automated revenue loss detection.")

    if st.session_state.get("batch_results") is None:
        st.warning("⚠️ Please run Batch Processing first.")
        return

    df = st.session_state["batch_results"].copy()

    # --- FILTERS ---
    c1, c2, c3 = st.columns(3)
    with c1:
        min_conf = st.slider("Minimum Confidence Threshold", 0, 100, 50)
    with c2:
        revenue_only = st.checkbox("Show Revenue Opportunities Only", value=True)

    if "confidence_score" in df.columns:
        df = df[df["confidence_score"] >= min_conf]
    if revenue_only and "revenue_opportunity" in df.columns:
        df = df[df["revenue_opportunity"] == True]

    # Funnel Metric Calculations
    total_calls = len(df)
    rev_calls = int(df["revenue_opportunity"].sum()) if "revenue_opportunity" in df.columns else 0
    requested = (df["appointment_status"] == "Requested").sum() if "appointment_status" in df.columns else 0
    scheduled = (df["appointment_status"] == "Scheduled").sum() if "appointment_status" in df.columns else 0

    # --- CONVERSION FUNNEL ---
    st.subheader("Revenue Conversion Funnel")
    funnel_data = pd.DataFrame({
        "Stage": ["Total Calls Analyzed", "Revenue Opportunities Detected", "Appointments Requested", "Appointments Scheduled"],
        "Count": [total_calls, rev_calls, requested, scheduled]
    })

    fig_funnel = px.funnel(funnel_data, x="Count", y="Stage", title="Opportunity Pipeline Progression")
    st.plotly_chart(fig_funnel, use_container_width=True)

    # --- AGENT & QUEUE PERFORMANCE (IF AVAILABLE) ---
    col1, col2 = st.columns(2)
    with col1:
        if "agent_name" in df.columns:
            st.subheader("Agent Performance")
            agent_summary = (
                df.groupby("agent_name")
                .agg(
                    Total_Calls=("revenue_opportunity", "count"),
                    Revenue_Ops=("revenue_opportunity", "sum"),
                    Avg_Confidence=("confidence_score", "mean")
                )
                .reset_index()
            )
            st.dataframe(agent_summary, use_container_width=True)

    with col2:
        if "queue_name" in df.columns:
            st.subheader("Queue Conversion Rates")
            fig_queue = px.bar(
                df.groupby("queue_name")["revenue_opportunity"].mean().reset_index(),
                x="queue_name",
                y="revenue_opportunity",
                title="Revenue Opportunity Rate by Queue"
            )
            st.plotly_chart(fig_queue, use_container_width=True)

    # --- AUTOMATED AI RECOMMENDATIONS ---
    st.subheader("💡 Automated AI Business Recommendations")
    conversion_rate = (requested / max(rev_calls, 1)) * 100

    recommendations = []
    if conversion_rate < 60:
        recommendations.append("⚠️ **Conversion Opportunity:** High number of revenue calls are ending without an appointment booking request. Review CSR closing tactics.")
    if "pricing_discussed" in df.columns and df["pricing_discussed"].sum() < (rev_calls * 0.3):
        recommendations.append("💡 **Pricing Transparency:** Pricing was mentioned in less than 30% of revenue opportunities. Consider agent refresher training.")
    if "confidence_score" in df.columns and df["confidence_score"].mean() < 75:
        recommendations.append("🔍 **Quality Alert:** Average AI confidence is under 75%. Inspect transcript quality or agent audio clarity.")

    if not recommendations:
        st.success("All operational KPIs are performing within optimal parameters!")
    else:
        for rec in recommendations:
            st.warning(rec)