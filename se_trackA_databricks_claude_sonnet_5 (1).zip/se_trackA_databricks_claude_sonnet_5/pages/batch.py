# import pandas as pd
# import streamlit as st
# from pipeline.inference import process_transcript


# def process_dataframe(
#     dataframe: pd.DataFrame, pipeline: dict, transcript_col: str = "transcription_text"
# ) -> pd.DataFrame:
#     """Runs the AI pipeline across a dataframe in batches with live progress tracking."""
#     results = []
#     total = len(dataframe)

#     progress_bar = st.progress(0)
#     status = st.empty()

#     for index, row in dataframe.iterrows():
#         status.info(f"Processing call {index + 1:,} of {total:,}...")
#         transcript = str(row.get(transcript_col, ""))

#         output = process_transcript(transcript, pipeline)
#         results.append(output)

#         progress_bar.progress((index + 1) / total)

#     progress_bar.empty()
#     status.success("Batch Analysis Completed!")

#     results_df = pd.DataFrame(results)
#     return pd.concat(
#         [dataframe.reset_index(drop=True), results_df.reset_index(drop=True)], axis=1
#     )


# def render_batch_page(pipeline: dict):
#     st.title("📂 Batch Processing")
#     st.caption("Run Revenue Opportunity Detection across bulk customer calls.")

#     # 1. Data Source Selection
#     source = st.radio(
#         "Choose Data Source",
#         ["Upload CSV", "Upload Excel", "Databricks Volume"],
#         horizontal=True,
#     )

#     dataframe = None

#     if source == "Upload CSV":
#         uploaded = st.file_uploader("Upload CSV File", type=["csv"])
#         if uploaded:
#             dataframe = pd.read_csv(uploaded)

#     elif source == "Upload Excel":
#         uploaded = st.file_uploader("Upload Excel File", type=["xlsx", "xls"])
#         if uploaded:
#             dataframe = pd.read_excel(uploaded)

#     else:
#         volume_path = st.text_input(
#             "Volume File Path",
#             placeholder="/Volumes/catalog/schema/input/transcripts.csv",
#         )
#         if st.button("Load Volume File") and volume_path:
#             try:
#                 dataframe = pd.read_csv(volume_path)
#             except Exception as e:
#                 st.error(f"Failed to load file from path: {e}")

#     if dataframe is None:
#         st.info("Please upload or load a dataset to begin.")
#         return

#     st.session_state["uploaded_df"] = dataframe

#     # 2. Dataset Preview Metrics
#     st.subheader("Dataset Preview")
#     st.dataframe(dataframe.head(5), use_container_width=True)

#     c1, c2, c3 = st.columns(3)
#     c1.metric("Rows", f"{len(dataframe):,}")
#     c2.metric("Columns", len(dataframe.columns))
#     c3.metric(
#         "Memory Size",
#         f"{round(dataframe.memory_usage().sum() / (1024 * 1024), 2)} MB",
#     )

#     # 3. Column Mapping Configuration
#     with st.expander("Column Mapping & Metadata"):
#         transcript_col = st.selectbox(
#             "Transcript Text Column",
#             options=dataframe.columns,
#             index=0
#             if "transcription_text" not in dataframe.columns
#             else list(dataframe.columns).index("transcription_text"),
#         )
#         call_id = st.selectbox("Call ID Column (Optional)", ["None"] + list(dataframe.columns))
#         agent = st.selectbox("Agent Column (Optional)", ["None"] + list(dataframe.columns))
#         queue = st.selectbox("Queue Column (Optional)", ["None"] + list(dataframe.columns))

#     # 4. Batch Settings
#     with st.expander("Execution Settings"):
#         max_rows = st.number_input(
#             "Maximum Rows to Process",
#             value=len(dataframe),
#             min_value=1,
#             max_value=len(dataframe),
#         )

#     # 5. Run Execution
#     if st.button("🚀 Run Batch Analysis", type="primary", use_container_width=True):
#         subset_df = dataframe.head(int(max_rows))

#         with st.spinner("Analyzing call transcripts..."):
#             results_df = process_dataframe(subset_df, pipeline, transcript_col=transcript_col)

#         st.session_state["batch_results"] = results_df
#         st.session_state["run_complete"] = True

#         st.success("Batch run finished successfully!")

#         # Summary KPIs
#         st.subheader("Batch Results Summary")
#         m1, m2, m3 = st.columns(3)
#         m1.metric("Calls Processed", f"{len(results_df):,}")
#         m2.metric("Revenue Opportunities", int(results_df["revenue_opportunity"].sum()))
#         m3.metric(
#             "Mean Confidence",
#             f"{round(results_df['confidence_score'].mean(), 1)}%",
#         )

#         st.dataframe(results_df, use_container_width=True)


####################################============================================#########################

import ast
import io
import json
import pandas as pd
import streamlit as st
import plotly.express as px
from pipeline.inference import process_transcript


def inject_batch_css():
    """Injects modern, high-contrast CSS for KPI cards, status badges, and table views."""
    st.markdown(
        """
    <style>
    /* Hide native Streamlit sidebar nav if present */
    [data-testid="stSidebarNav"] {
        display: none !important;
    }

    /* KPI Grid Cards */
    .kpi-card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 18px 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.03);
        transition: transform 0.15s ease;
    }
    .kpi-card:hover {
        transform: translateY(-2px);
    }
    .kpi-label {
        font-size: 0.8rem;
        font-weight: 700;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 6px;
    }
    .kpi-value {
        font-size: 1.8rem;
        font-weight: 800;
        color: #0f172a;
    }
    .kpi-subtext {
        font-size: 0.8rem;
        color: #10b981;
        font-weight: 600;
        margin-top: 4px;
    }

    /* Custom Table Container */
    .table-header {
        font-size: 1.1rem;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 12px;
    }

    /* Status Pill Badges */
    .pill-yes {
        background-color: #dcfce7;
        color: #15803d;
        font-weight: 700;
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 0.8rem;
    }
    .pill-no {
        background-color: #f1f5f9;
        color: #64748b;
        font-weight: 600;
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 0.8rem;
    }
    .pill-urgency-high {
        background-color: #fee2e2;
        color: #b91c1c;
        font-weight: 700;
        padding: 3px 10px;
        border-radius: 12px;
        font-size: 0.8rem;
    }

    /* Detailed Drawer / Inspector Card */
    .inspector-card {
        background-color: #f8fafc;
        border: 1px solid #cbd5e1;
        border-radius: 10px;
        padding: 20px;
        margin-top: 10px;
    }
    .evidence-box {
        background-color: #ffffff;
        border-left: 4px solid #7c3aed;
        border-radius: 6px;
        padding: 10px 14px;
        margin-top: 8px;
        font-style: italic;
        color: #334155;
        font-size: 0.9rem;
    }
    </style>
    """,
        unsafe_allow_html=True,
    )


def get_sample_batch_data():
    """Generates mock sample data if user doesn't upload a CSV/Excel file."""
    return pd.DataFrame([
        {
            "call_id": "CALL-1001",
            "transcript_text": "Customer: My AC unit is blowing warm air and making a loud clicking noise. I need someone to come fix it today.\nAgent: We can dispatch a technician between 2 PM and 5 PM today. The service fee is $79.\nCustomer: Perfect, please book it."
        },
        {
            "call_id": "CALL-1002",
            "transcript_text": "Customer: Hi, I'm calling to ask what your general hours are on weekends?\nAgent: We operate from 8 AM to 5 PM on Saturdays.\nCustomer: Great, thanks for the info!"
        },
        {
            "call_id": "CALL-1003",
            "transcript_text": "Customer: There is water leaking under my kitchen sink and flooding the cabinet!\nAgent: That sounds urgent. I can have a plumber at your location within 2 hours.\nCustomer: Yes, please send them right away!"
        },
        {
            "call_id": "CALL-1004",
            "transcript_text": "Customer: Can I get a quote for replacing a 50-gallon water heater?\nAgent: Sure, our tankless and standard tank replacements start around $1,200 including installation.\nCustomer: Okay, let me talk to my spouse and call you back."
        }
    ])


def run_batch_processing(df: pd.DataFrame, pipeline) -> pd.DataFrame:
    """Processes each row of the dataset and appends structured AI fields."""
    results = []
    total = len(df)
    progress_bar = st.progress(0)
    status_text = st.empty()

    for idx, row in df.iterrows():
        call_id = row.get("call_id", f"CALL-{idx+1000}")
        text = str(row.get("transcription_text", "")
        )

        status_text.text(f"Analyzing {call_id} ({idx+1}/{total})...")
        try:

            # Execute Pipeline
            ai_output = process_transcript(text, pipeline)
            if not isinstance(ai_output, dict):
                ai_output = {}
        except Exception as e:
            ai_output = {}
            print(f"Error processing {call_id}: {e}")

        # Build clean schema object
        record = {
            "call_id": call_id,
            "transcription_text": text,
            "core_intent": ai_output.get("core_intent"),
            "customer_problem": ai_output.get("customer_problem", ""),
            "customer_goal": ai_output.get("customer_goal", "N/A"),
            "requested_service": ai_output.get("requested_service", "N/A"),
            "trade": ai_output.get("trade", "General Maintenance"),
            "service_category": ai_output.get("service_category", ""),
            "urgency": ai_output.get("urgency", "low"),
            "appointment_status": ai_output.get("appointment_status", "Not Discussed"),
            "pricing_discussed": bool(ai_output.get("pricing_discussed", False)),
            "revenue_opportunity": bool(ai_output.get("revenue_opportunity", False)),
            "intent_strength": int(ai_output.get("intent_strength", 1)),
            "confidence": ai_output.get("confidence", "Medium"),
            "confidence_score": int(ai_output.get("confidence_score", 85)),
            "evidence": json.dumps(ai_output.get("evidence", []),ensure_ascii=False),
            "business_reason": ai_output.get("business_reason", ""),
            # "status": ai_output.get("status", "N/A").get("evidence", []),
            "business_summary": ai_output.get("business_summary", ""),
        }
        results.append(record)
    progress_bar.progress((idx + 1) / total)
    status_text.text(f"Finished analyzing {call_id}!")

    progress_bar.empty()
    results_df = pd.DataFrame(results)
    st.write(results_df.columns.tolist())
    return pd.DataFrame(results_df)


def render_batch_page(pipeline):
    inject_batch_css()

    st.title("📂 Batch Report & Processing Center")
    st.caption("Bulk analysis pipeline for processing transcript batches into actionable intelligence schemas.")

    # Step 1: Input Options
    st.markdown("### 1. Data Ingestion")
    c1, c2 = st.columns([2, 1])

    with c1:
        uploaded_file = st.file_uploader(
            "Upload Call Transcripts (CSV or Excel)",
            type=["csv", "xlsx"],
            help="File must contain 'call_id' and 'transcript_text' columns.",
        )

    with c2:
        st.markdown("<br>", unsafe_allow_html=True)
        use_sample = st.button("⚡ Load Demo Batch (4 Calls)", use_container_width=True)

    input_df = None
    if uploaded_file is not None:
        try:
            if uploaded_file.name.endswith(".csv"):
                input_df = pd.read_csv(uploaded_file)
            else:
                input_df = pd.read_excel(uploaded_file)
            st.success(f"Successfully loaded file: {len(input_df)} rows detected.")
        except Exception as e:
            st.error(f"Error reading file: {e}")
    elif use_sample:
        input_df = get_sample_batch_data()
        st.info("Loaded 4 sample calls into processing queue.")

    # Step 2: Trigger Processing
    if input_df is not None:
        if st.button("🚀 Execute Batch Pipeline", type="primary", use_container_width=True):
            with st.spinner("Executing model pipeline on batch dataset..."):
                processed_df = run_batch_processing(input_df,pipeline)
                st.session_state["batch_report_data"] = processed_df
                st.success("Batch processing completed!")

    # Step 3: Render Report & Dashboard
    if "batch_report_data" in st.session_state:
        df = st.session_state["batch_report_data"]

        st.divider()
        st.markdown("### 2. Executive KPI Summary")

        # Top Metric Cards
        total_calls = len(df)
        rev_opps = int(df["revenue_opportunity"].sum())
        rev_pct = round((rev_opps / max(total_calls, 1)) * 100, 1)
        avg_intent = round(df["intent_strength"].mean(), 1)
        high_urgency = int((df["urgency"].str.lower().isin(["high", "emergency"])).sum())

        k1, k2, k3, k4 = st.columns(4)
        with k1:
            st.markdown(
                f"""
                <div class="kpi-card">
                    <div class="kpi-label">Total Processed Calls</div>
                    <div class="kpi-value">{total_calls}</div>
                    <div class="kpi-subtext">100% Validated</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        with k2:
            st.markdown(
                f"""
                <div class="kpi-card">
                    <div class="kpi-label">Revenue Opportunities</div>
                    <div class="kpi-value">{rev_opps}</div>
                    <div class="kpi-subtext">🟢 {rev_pct}% Opportunity Rate</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        with k3:
            st.markdown(
                f"""
                <div class="kpi-card">
                    <div class="kpi-label">Avg Intent Score</div>
                    <div class="kpi-value">{avg_intent} / 5</div>
                    <div class="kpi-subtext">High Conversion Potential</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        with k4:
            st.markdown(
                f"""
                <div class="kpi-card">
                    <div class="kpi-label">High / Urgent Calls</div>
                    <div class="kpi-value">{high_urgency}</div>
                    <div class="kpi-subtext" style="color:#ef4444;">Requires Fast Follow-up</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

        st.markdown("<br>", unsafe_allow_html=True)

        # Charts Section
        ch1, ch2 = st.columns(2)
        with ch1:
            fig_rev = px.pie(
                df,
                names="revenue_opportunity",
                title="Revenue Opportunity Split",
                color="revenue_opportunity",
                color_discrete_map={True: "#22c55e", False: "#cbd5e1"},
            )
            fig_rev.update_layout(margin=dict(t=40, b=10, l=10, r=10), height=280)
            st.plotly_chart(fig_rev, use_container_width=True)

        with ch2:
            fig_trade = px.bar(
                df["trade"].value_counts().reset_index(),
                x="trade",
                y="count",
                title="Calls by Trade Category",
                color="trade",
                color_discrete_sequence=px.colors.qualitative.Bold,
            )
            fig_trade.update_layout(margin=dict(t=40, b=10, l=10, r=10), height=280)
            st.plotly_chart(fig_trade, use_container_width=True)

        st.divider()

        # Step 4: Full Batch Report Data Table
        st.markdown("### 3. Comprehensive Batch Schema Report")

        # Prep display dataframe (convert lists/dict to string for clean table render)
        display_df = df.copy()
        display_df["evidence"] = display_df["evidence"].apply(lambda x: str(x) if isinstance(x, list) else str(x))

        # Filter bar
        col_f1, col_f2 = st.columns([1, 1])
        with col_f1:
            trade_filter = st.multiselect(
                "Filter by Trade",
                options=list(df["trade"].unique()),
                default=list(df["trade"].unique()),
            )
        with col_f2:
            rev_filter = st.multiselect(
                "Filter by Revenue Opportunity",
                options=[True, False],
                default=[True, False],
            )

        filtered_df = display_df[
            (display_df["trade"].isin(trade_filter)) &
            (display_df["revenue_opportunity"].isin(rev_filter))
        ]

        # Display Data Grid
        st.dataframe(
            filtered_df,
            column_config={
                "call_id": st.column_config.TextColumn("Call ID", width="medium"),
                "revenue_opportunity": st.column_config.CheckboxColumn("Revenue Opp"),
                "intent_strength": st.column_config.ProgressColumn("Intent Strength", min_value=1, max_value=5),
                "confidence_score": st.column_config.NumberColumn("Confidence (%)", format="%d%%"),
                "transcript_text": st.column_config.TextColumn("Transcript Snippet", width="large"),
            },
            use_container_width=True,
            height=320,
        )

        # Download Report Buttons
        d1, d2 = st.columns(2)
        with d1:
            csv_data = filtered_df.to_csv(index=False).encode("utf-8")
            st.download_button(
                "📥 Download CSV Report",
                data=csv_data,
                file_name="service_experts_batch_report.csv",
                mime="text/csv",
                use_container_width=True,
            )
        with d2:
            # Excel export stream
            buffer = io.BytesIO()
            with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
                filtered_df.to_excel(writer, index=False, sheet_name="Batch_Report")
            st.download_button(
                "📊 Download Excel Report",
                data=buffer.getvalue(),
                file_name="service_experts_batch_report.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
            )

        st.divider()

        # Step 5: Individual Record Inspector
        st.markdown("### 🔍 Call Record Inspector")
        st.caption("Select a call ID to inspect its extracted schema and evidence quotes.")

        selected_id = st.selectbox("Select Call ID", options=df["call_id"].tolist())
        selected_row = df[df["call_id"] == selected_id].iloc[0]

        st.markdown(
            f"""
            <div class="inspector-card">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <h3 style="margin:0; color:#0f172a;">📌 {selected_row['call_id']} — {selected_row['core_intent']}</h3>
                    <span class="pill-yes">Revenue Opp: {selected_row['revenue_opportunity']}</span>
                </div>
                <hr style="margin: 12px 0;">
                <p><b>Summary:</b> {selected_row['business_summary']}</p>
                <p><b>Customer Problem:</b> {selected_row['customer_problem']}</p>
                <p><b>Goal:</b> {selected_row['customer_goal']} | <b>Requested Service:</b> {selected_row['requested_service']}</p>
                <p><b>Trade:</b> {selected_row['trade']} | <b>Urgency:</b> {selected_row['urgency']} | <b>Appointment Status:</b> {selected_row['appointment_status']}</p>
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.markdown("#### Supporting Evidence Quotes")
        evidence_data = selected_row["evidence"]
        if isinstance(evidence_data, list) and len(evidence_data) > 0:
            for item in evidence_data:
                quote_str = item.get("text", str(item)) if isinstance(item, dict) else str(item)
                st.markdown(f'<div class="evidence-box">"{quote_str}"</div>', unsafe_allow_html=True)
        else:
            st.info("No supporting quotes extracted.")


# if __name__ == "__main__":
    # render_batch_page()