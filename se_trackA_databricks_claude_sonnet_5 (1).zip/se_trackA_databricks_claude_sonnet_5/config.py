import os
from pathlib import Path

# Base Paths
BASE_DIR = Path(__file__).resolve().parent
ASSETS_DIR = BASE_DIR / "assets"

# LLM Configuration
LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "claude-3-5-sonnet-20241022")
EMBEDDING_MODEL_NAME = os.getenv("EMBEDDING_MODEL_NAME", "all-MiniLM-L6-v2")

# Classification Constants
DEFAULT_CONFIDENCE_THRESHOLD = 75
SUPPORTED_TRADES = ["HVAC", "Plumbing", "Electrical", "Roofing", "General Maintenance"]
URGENCY_LEVELS = ["low", "medium", "high", "emergency"]
APPOINTMENT_STATUSES = ["Not Discussed", "Requested", "Scheduled", "Declined"]

# Output Schema Baseline
DEFAULT_ANALYSIS_SCHEMA = {
    "core_intent": "Unknown",
    "customer_problem": "N/A",
    "customer_goal": "N/A",
    "requested_service": "N/A",
    "trade": "General Maintenance",
    "service_category": "General",
    "urgency": "low",
    "appointment_status": "Not Discussed",
    "pricing_discussed": False,
    "revenue_opportunity": False,
    "intent_strength": 0,
    "confidence": "Low",
    "confidence_score": 0,
    "business_summary": "No analysis performed.",
    "business_reason": "N/A",
    "evidence": []
}

SYSTEM_PROMPT = """You are an expert AI Revenue Opportunity Intelligence system for Service Experts.
Your task is to analyze customer conversation transcripts, extract intent metrics, classify trade categories, 
and detect clear revenue opportunities (e.g., service calls, replacements, maintenance sign-ups).

Respond strictly with a valid JSON object matching the requested schema.
"""