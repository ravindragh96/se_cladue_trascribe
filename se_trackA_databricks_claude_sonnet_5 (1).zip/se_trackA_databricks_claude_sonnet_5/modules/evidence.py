"""
==============================================================================
Track A - Service Experts Revenue Opportunity Detection

Evidence Extractor

Responsibilities
----------------
1. Split transcript into semantic chunks
2. Generate embeddings
3. Compute similarity
4. Return top supporting evidence

This module has NO business logic.
==============================================================================
"""

import logging
from typing import List, Dict

import numpy as np

from models.model_registry import ModelRegistry

logger = logging.getLogger(__name__)
# ==============================================================================
# Evidence Extractor
# ==============================================================================

class EvidenceExtractor:
    """
    Retrieves the most relevant transcript segments supporting the
    predicted revenue opportunity.
    """

    def __init__(
        self,
        registry: ModelRegistry,
        top_k: int = 5
    ):

        self.registry = registry

        self.embedding_model = registry.load_embedding_model()

        self.top_k = top_k
        # ------------------------------------------------------------------
    # Chunk Transcript
    # ------------------------------------------------------------------

    @staticmethod
    def chunk_transcript(
        transcript: str,
        min_length: int = 20
    ) -> List[str]:
        """
        Split transcript into meaningful conversational chunks.
        """

        if not transcript:
            return []

        transcript = transcript.replace("\r", "\n")

        chunks = []

        for line in transcript.split("\n"):

            line = line.strip()

            if len(line) < min_length:
                continue

            chunks.append(line)

        return chunks
        # ------------------------------------------------------------------
    # Generate Embeddings
    # ------------------------------------------------------------------

    def generate_embeddings(
        self,
        texts: List[str]
    ) -> np.ndarray:
        """
        Generates embeddings for transcript chunks.
        """

        if not texts:
            return np.empty((0, 384))

        embeddings = self.embedding_model.encode(
            texts,
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=False
        )

        return embeddings

    # ------------------------------------------------------------------
    # Cosine Similarity
    # ------------------------------------------------------------------

    @staticmethod
    def cosine_similarity(
        query_embedding: np.ndarray,
        chunk_embeddings: np.ndarray
    ) -> np.ndarray:
        """
        Computes cosine similarity between the query embedding
        and all transcript chunk embeddings.
        """

        if chunk_embeddings.size == 0:
            return np.array([])

        similarities = np.dot(
            chunk_embeddings,
            query_embedding
        )

        return similarities

    # ------------------------------------------------------------------
    # Rank Chunks
    # ------------------------------------------------------------------

    def rank_chunks(
        self,
        query: str,
        transcript_chunks: List[str]
    ) -> List[Dict]:
        """
        Returns transcript chunks ranked by semantic similarity.
        """

        if not transcript_chunks:
            return []

        chunk_embeddings = self.generate_embeddings(
            transcript_chunks
        )

        query_embedding = self.embedding_model.encode(
            query,
            convert_to_numpy=True,
            normalize_embeddings=True
        )

        similarities = self.cosine_similarity(
            query_embedding,
            chunk_embeddings
        )

        ranked = []

        for idx, score in enumerate(similarities):

            ranked.append({

                "text": transcript_chunks[idx],

                "score": float(score)

            })

        ranked.sort(
            key=lambda x: x["score"],
            reverse=True
        )

        return ranked
        # ------------------------------------------------------------------
    # Extract Evidence
    # ------------------------------------------------------------------

    def extract(
        self,
        transcript: str,
        analysis_result: Dict,
        top_k: int = None
    ) -> List[Dict]:
        """
        Extract the top supporting evidence from the transcript.

        Parameters
        ----------
        transcript : Full conversation transcript

        analysis_result : Output of RevenueOpportunityAnalyzer

        top_k : Number of evidence chunks to return

        Returns
        -------
        [
            {
                "text": "...",
                "score": 0.92
            }
        ]
        """

        if top_k is None:
            top_k = self.top_k

        chunks = self.chunk_transcript(transcript)

        if not chunks:
            return []

        # --------------------------------------------------------------
        # Build Semantic Search Query
        # --------------------------------------------------------------

        query_parts = [

            analysis_result.get("core_intent", ""),

            analysis_result.get("customer_problem", ""),

            analysis_result.get("customer_goal", ""),

            analysis_result.get("requested_service", ""),

            analysis_result.get("trade", ""),

            analysis_result.get("service_category", "")
        ]

        query = " ".join(
            x.strip()
            for x in query_parts
            if x
        )

        if not query.strip():

            query = transcript[:500]

        ranked_chunks = self.rank_chunks(
            query=query,
            transcript_chunks=chunks
        )

        return ranked_chunks[:top_k]

    # ------------------------------------------------------------------
    # Attach Evidence
    # ------------------------------------------------------------------

    def enrich(
        self,
        transcript: str,
        analysis_result: Dict
    ) -> Dict:
        """
        Appends semantic evidence to detector output.
        """

        result = analysis_result.copy()

        result["evidence"] = self.extract(
            transcript=transcript,
            analysis_result=analysis_result
        )

        return result
        # ------------------------------------------------------------------
    # Callable Interface
    # ------------------------------------------------------------------

    def __call__(
        self,
        transcript: str,
        analysis_result: Dict
    ) -> Dict:
        """
        Allows the extractor to be called like a function.

        Example
        -------
        enriched = extractor(
            transcript,
            detector_output
        )
        """

        return self.enrich(
            transcript=transcript,
            analysis_result=analysis_result
        )


# ==============================================================================
# Factory
# ==============================================================================

def create_evidence_extractor(
    registry: ModelRegistry,
    top_k: int = 5
) -> EvidenceExtractor:
    """
    Factory function for creating the EvidenceExtractor.

    Parameters
    ----------
    registry : ModelRegistry
        Shared model registry instance.

    top_k : int
        Number of evidence chunks to return.

    Returns
    -------
    EvidenceExtractor
    """

    return EvidenceExtractor(
        registry=registry,
        top_k=top_k
    )