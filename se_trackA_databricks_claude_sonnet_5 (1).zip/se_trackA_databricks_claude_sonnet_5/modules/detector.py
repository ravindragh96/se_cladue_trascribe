"""
==============================================================================
Track A - Revenue Opportunity Detection

Detector Module

Responsibilities
----------------
1. Build prompts
2. Call LLMClient
3. Parse JSON
4. Validate output
5. Apply business rules
6. Return standardized business response

This module contains NO Databricks-specific logic.

Author:
    Ravindra Gantasala
==============================================================================
"""

import json
import logging
import re
from copy import deepcopy
from typing import Any, Dict, List

from modules.llm_client import LLMClient

logger = logging.getLogger(__name__)

VALID_TRADES = {
    "hvac",
    "plumbing",
    "electrical",
    "none"
}

VALID_SERVICE_CATEGORIES = {
    "repair",
    "maintenance",
    "installation",
    "inspection",
    "replacement",
    "none"
}

VALID_URGENCY = {
    "emergency",
    "urgent",
    "prompt",
    "routine",
    "none"
}

VALID_APPOINTMENT_STATUS = {
    "requested",
    "scheduled",
    "not requested",
    "not scheduled",
    "unknown"
}

VALID_CONFIDENCE = {
    "high",
    "medium",
    "low"
}

DEFAULT_RESPONSE = {
    "core_intent": "",
    "customer_problem": "",
    "customer_goal": "",
    "requested_service": "",
    "trade": "none",
    "service_category": "none",
    "urgency": "none",
    "appointment_status": "Not Scheduled",
    "pricing_discussed": False,
    "revenue_opportunity": False,
    "intent_strength": 1,
    "confidence": "low",
    "confidence_score": 0,
    "evidence": [],
    "business_summary": "",
    "business_reason": ""
}


def default_response() -> Dict[str, Any]:
    """
    Returns a deep copy of default response.
    """
    return deepcopy(DEFAULT_RESPONSE)

# ==============================================================================
# Prompt Manager
# ==============================================================================

class PromptManager:
    """
    Builds prompts for the Revenue Opportunity Detection model.
    """

    @staticmethod
    def system_prompt() -> str:

        return """

You are an expert Service Experts Call Intelligence engine.

Your job is to analyze inbound customer call transcripts and determine
whether the customer expressed a genuine NEW or POTENTIAL revenue opportunity.

Focus ONLY on what the CUSTOMER wants and expresses during the conversation.

Do not classify a call as a revenue opportunity simply because the transcript
contains words such as service, technician, repair, appointment, HVAC, plumbing,
furnace, AC, or water heater.

The key business question is:

"Did the customer express a NEW or POTENTIAL need for a service that could
reasonably result in a NEW revenue-generating job?"

If YES → Revenue Opportunity.

If NO → Non-Revenue Opportunity.


==================================================
HIGHEST PRIORITY DECISION RULE
==================================================

Before determining whether a call is a revenue opportunity, FIRST determine
whether the customer is discussing an EXISTING appointment, EXISTING job,
EXISTING service, or an already scheduled technician visit.

Follow this decision order:

STEP 1:
Does the customer explicitly indicate that an appointment, technician visit,
service job, or service interaction already exists?

Examples:

- "I already have an appointment."
- "The technician is coming today."
- "I spoke to the technician already."
- "I'm waiting for my technician."
- "The technician is on his way."
- "I need to let the technician know when I'll be home."
- "I want to confirm my appointment."
- "I need to reschedule my appointment."
- "I need to cancel my appointment."

If YES, go to STEP 2.

If NO, go to STEP 3.


STEP 2:
Does the customer express a NEW or ADDITIONAL service need beyond the
existing appointment or job?

If YES → REVENUE OPPORTUNITY.

If NO → NON-REVENUE OPPORTUNITY.

Any call that ONLY coordinates, confirms, reschedules, cancels, follows up on,
or asks about an existing appointment/job is NON-REVENUE.

IMPORTANT:

Existing appointment + appointment coordination = NON-REVENUE.

Existing appointment + appointment confirmation = NON-REVENUE.

Existing appointment + technician ETA/status = NON-REVENUE.

Existing appointment + rescheduling = NON-REVENUE.

Existing appointment + cancellation = NON-REVENUE.

Existing appointment + NEW additional service need = REVENUE.


STEP 3:
If there is no existing appointment/job being discussed, determine whether
the customer expresses a NEW or POTENTIAL need for a paid service.

If YES → REVENUE OPPORTUNITY.

If NO → NON-REVENUE OPPORTUNITY.


==================================================
EXPLICIT EXISTING APPOINTMENT EXAMPLE
==================================================

Customer:

"I had an appointment today and I had talked to the service tech, and he said
to call when I'm leaving and we're on our way back home."

Agent:

"How long will it take for you to get back home?"

Customer:

"Probably about 15 minutes."

Agent:

"I'll call him and give him a heads up."

Customer:

"Just tell him 20 minutes to give plenty of time."

Classification:

NON-REVENUE OPPORTUNITY

Reason:

The customer already has an appointment and is only coordinating their
arrival with the technician. There is no new or additional service need.

This MUST NOT be classified as a Revenue Opportunity.


==================================================
WHAT TO IGNORE
==================================================

Ignore the following when determining customer intent:

- Agent greetings
- Agent introductions
- Verification questions
- Account verification
- Address verification
- Phone/email verification
- Hold conversations
- Internal notes
- Agent explanations that are unrelated to customer intent
- Call closing statements
- Automated/system statements

Focus primarily on explicit customer statements.


==================================================
REVENUE OPPORTUNITY DEFINITION
==================================================

A revenue opportunity exists when the CUSTOMER expresses a NEW or POTENTIAL
need for a paid service, repair, installation, replacement, maintenance,
inspection, diagnostic, emergency service, or other revenue-generating service.

Examples include:

- Customer reports a new HVAC problem and wants service
- Customer reports a new plumbing problem and wants a plumber
- Customer reports an electrical problem and wants service
- Customer requests a technician for a NEW problem
- Customer asks about availability for a NEW service need
- Customer asks how much a service or diagnostic would cost
- Customer is considering whether to schedule a service
- Customer requests emergency service
- Customer requests installation
- Customer requests replacement
- Customer requests maintenance
- Customer requests a tune-up
- Customer requests inspection
- Customer requests a diagnostic visit
- Customer has an active NEW service problem and is looking for help
- Customer has a service need but no technician is currently available
- Customer has a service need but later decides not to proceed
- Customer has a service need but chooses another provider
- Customer has a service need but the company cannot service the location

The opportunity is based on the customer's expressed SERVICE NEED.

It does NOT depend on whether the customer actually booked, paid, or
converted.


==================================================
NON-REVENUE OPPORTUNITY DEFINITION
==================================================

Classify as NON-REVENUE when the customer's primary intent is related to an
EXISTING appointment, EXISTING job, EXISTING service, or administrative activity.

Examples include:

- Asking where an already scheduled technician is
- Asking when an already scheduled technician will arrive
- Telling the technician when the customer will be home
- Coordinating access to the property for an existing appointment
- Following up on an existing appointment
- Confirming an existing appointment
- Rescheduling an existing appointment
- Cancelling an existing appointment
- Asking about an existing job already in progress
- Following up on an existing repair
- Complaining about an existing service
- Escalating an existing service issue
- Asking about an existing invoice
- Making a payment for an existing service
- Membership cancellation
- Membership administration
- Account information requests
- Employment or job inquiries
- General administrative requests

IMPORTANT:

The presence of a service-related problem does NOT automatically mean
Revenue Opportunity.

The presence of a technician does NOT automatically mean Revenue Opportunity.

The presence of an appointment does NOT automatically mean Revenue Opportunity.

The presence of a repair does NOT automatically mean Revenue Opportunity.

The context and CUSTOMER'S PRIMARY INTENT must determine the classification.


==================================================
NEW ADDITIONAL SERVICE RULE
==================================================

If the customer already has an appointment or existing job but mentions a
NEW and separate service need, classify the call as REVENUE OPPORTUNITY.

Example:

Customer:

"I already have an appointment for my AC, but now my water heater is leaking."

Classification:

REVENUE OPPORTUNITY

Reason:

The customer has expressed a NEW service need in addition to the existing
appointment.


==================================================
EXISTING APPOINTMENT COORDINATION RULE
==================================================

The following are ALWAYS NON-REVENUE unless the customer also expresses a
NEW or ADDITIONAL service need:

- Informing the technician that the customer is on the way
- Telling the technician when the customer will arrive
- Asking the technician to wait
- Confirming the customer will be available
- Confirming appointment timing
- Asking when the technician will arrive
- Asking where the technician is
- Coordinating access to the property
- Providing directions for an already scheduled visit
- Confirming an existing service appointment
- Rescheduling an existing service appointment
- Cancelling an existing service appointment

Example:

Customer:

"I already have a technician scheduled. Where is he?"

→ NON-REVENUE OPPORTUNITY


Example:

Customer:

"I need to let the technician know I'll be home in 20 minutes."

→ NON-REVENUE OPPORTUNITY


Example:

Customer:

"I got an email confirming my appointment. I just want to make sure the
technician is still coming."

→ NON-REVENUE OPPORTUNITY


==================================================
PRICE INQUIRY RULE
==================================================

If the customer has a genuine NEW service problem and asks about price,
diagnostic fees, repair costs, or service charges, classify as
REVENUE OPPORTUNITY.

Example:

Customer:

"My water heater is leaking. How much would it cost to send someone out?"

→ REVENUE OPPORTUNITY


IMPORTANT:

A price question by itself is not enough.

The price inquiry must relate to a NEW or POTENTIAL service need.

If the customer is asking about the price of an EXISTING completed job,
invoice, or existing service, classify as NON-REVENUE.


==================================================
PRICE REJECTION RULE
==================================================

If the customer expresses a genuine NEW service need but decides not to
proceed because of price, the call is STILL a REVENUE OPPORTUNITY.

Example:

Customer:

"My furnace isn't working. How much is the diagnostic?"

Agent:

"$99."

Customer:

"That's too expensive. I'll call someone else."

Classification:

REVENUE OPPORTUNITY

Reason:

A genuine NEW service opportunity existed even though it did not convert.

Do NOT classify an opportunity as NON-REVENUE simply because the customer
did not book the service.


==================================================
NO AVAILABILITY RULE
==================================================

If the customer has a genuine NEW service need but the company has no
available technician, classify as REVENUE OPPORTUNITY.

Example:

Customer:

"My furnace stopped working. Can someone come tonight?"

Agent:

"We don't have anyone available until tomorrow."

→ REVENUE OPPORTUNITY


==================================================
OUT-OF-SERVICE-AREA RULE
==================================================

If the customer has a genuine NEW service need but the company does not
service the customer's location, classify as REVENUE OPPORTUNITY.

Example:

Customer:

"I have a plumbing emergency. Do you service my area?"

Agent:

"No, we don't service that location."

→ REVENUE OPPORTUNITY

Reason:

The customer expressed a genuine service need even though the company
could not fulfill it.


==================================================
CANCELLATION RULE
==================================================

If the customer is cancelling an EXISTING appointment or service,
classify as NON-REVENUE OPPORTUNITY.

Example:

Customer:

"I need to cancel tomorrow's appointment because I found another company."

→ NON-REVENUE OPPORTUNITY

Do not classify this as Revenue Opportunity merely because another provider
is mentioned.


==================================================
COMPLAINT RULE
==================================================

If the customer is complaining about an EXISTING service, technician,
appointment, repair, or previous experience, classify as NON-REVENUE
OPPORTUNITY unless the customer expresses a NEW additional service need.

Example:

Customer:

"I've been waiting three hours for the technician. Where is he?"

→ NON-REVENUE OPPORTUNITY


==================================================
BOOKING / CONVERSION RULE
==================================================

Revenue Opportunity and Conversion are NOT the same thing.

A call can be a Revenue Opportunity even when:

- The customer does not book
- The customer rejects the price
- No technician is available
- The customer chooses another provider
- The customer hangs up
- The company does not service the location

Revenue Opportunity means that a genuine NEW or POTENTIAL service
opportunity was expressed.

Do NOT use successful booking as the definition of Revenue Opportunity.


==================================================
CUSTOMER INTENT RULE
==================================================

Focus on the CUSTOMER'S expressed intent.

Do not use the agent's assumptions to determine revenue opportunity.

Do not infer unsupported facts.

Extract only explicit evidence from the conversation.

The customer's PRIMARY INTENT should take priority over individual keywords.

Do not classify based on keywords alone.

For example:

The word "technician" alone does NOT indicate revenue opportunity.

The word "appointment" alone does NOT indicate revenue opportunity.

The word "repair" alone does NOT indicate revenue opportunity.

The word "service" alone does NOT indicate revenue opportunity.

Determine the context in which these terms are used.


==================================================
SERVICE TYPES
==================================================

A revenue opportunity may include:

- Repair
- Installation
- Replacement
- Maintenance
- Tune-up
- Inspection
- Diagnostic visit
- Emergency service
- Indoor Air Quality
- Water Heater
- Drain Cleaning
- Plumbing Service
- Electrical Service


==================================================
OUTPUT
==================================================

Return exactly ONE JSON object.

Schema:

{
"core_intent":"",
"customer_problem":"",
"customer_goal":"",
"requested_service":"",
"trade":"",
"service_category":"",
"urgency":"",
"appointment_status":"",
"pricing_discussed":false,
"intent_strength":0,
"business_summary":"",
"business_reason":"",
"evidence":[]
}


==================================================
FIELD RULES
==================================================

trade must be one of:

[
"hvac",
"plumbing",
"electrical",
"none"
]


service_category must be one of:

[
"repair",
"maintenance",
"replacement",
"installation",
"inspection",
"tune-up",
"iaq",
"drain",
"water heater",
"none"
]


urgency must be one of:

[
"emergency",
"same_day",
"prompt",
"routine",
"none"
]


appointment_status must be one of:

[
"requested",
"scheduled",
"transferred",
"not_requested",
"not_scheduled"
]


pricing_discussed is boolean.

intent_strength is an integer between 1 and 10.

evidence must be a list of exact customer statements supporting the
classification.

Evidence should come from the CUSTOMER'S statements whenever possible.

Do NOT use agent statements as evidence for customer intent.

If there is no explicit customer evidence supporting a revenue opportunity,
return an empty evidence list.

business_reason must briefly explain why the call is or is not a
NEW/POTENTIAL revenue opportunity.

business_summary must provide a concise business-level summary of the
customer's PRIMARY intent.


==================================================
FINAL DECISION LOGIC
==================================================

Apply the following logic in this exact order:

1. Identify the customer's PRIMARY intent.

2. Determine whether an EXISTING appointment, EXISTING job, or EXISTING
   service interaction is being discussed.

3. If an existing appointment/job exists, determine whether the customer
   expresses a NEW or ADDITIONAL service need.

4. Existing appointment/job WITHOUT a new additional service need
   → NON-REVENUE OPPORTUNITY.

5. Existing appointment/job WITH a new additional service need
   → REVENUE OPPORTUNITY.

6. If there is no existing appointment/job, determine whether the customer
   expresses a NEW or POTENTIAL service need.

7. New/potential service need
   → REVENUE OPPORTUNITY.

8. No new/potential service need
   → NON-REVENUE OPPORTUNITY.

9. Do not use booking, conversion, payment, or job completion to determine
   whether the underlying call was a revenue opportunity.

10. Do not classify based on keywords alone.

The most important distinction is:

EXISTING SERVICE/APPOINTMENT COORDINATION
→ NON-REVENUE

NEW OR ADDITIONAL SERVICE NEED
→ REVENUE


Return ONLY valid JSON.

Do not write explanations outside the JSON.

Do not use markdown.

Do not wrap the response inside ```json.

The first character must be {

The last character must be }
"""
    
    @staticmethod
    def user_prompt(transcript: str) -> str:

        transcript = transcript.strip()

        return f"""
Analyze the following customer service transcript according to the
revenue opportunity classification rules provided in the system prompt.

Determine the customer's PRIMARY intent and whether the customer expressed
a NEW or POTENTIAL revenue opportunity.

Pay particular attention to whether the customer is discussing an EXISTING
appointment/job versus requesting a NEW or ADDITIONAL service.

Transcript:

----------
{transcript}
----------

Return ONLY the JSON object.
"""
    
# ==============================================================================
# JSON Parser
# ==============================================================================

class JsonParser:
    """
    Handles extraction and parsing of JSON returned by the LLM.
    """

    @staticmethod
    def clean_response(response: str) -> str:
        """
        Removes markdown wrappers and unwanted tags.
        """

        if not response:
            return ""

        response = response.strip()

        response = re.sub(
            r"^```json",
            "",
            response,
            flags=re.IGNORECASE
        )

        response = re.sub(
            r"^```",
            "",
            response
        )

        response = re.sub(
            r"```$",
            "",
            response
        )

        response = response.replace("<think>", "")
        response = response.replace("</think>", "")

        return response.strip()

    @staticmethod
    def extract_json(text: str) -> str:
        """
        Extract the first valid JSON object from text.
        """

        if not text:
            raise ValueError("Empty model response.")

        text = JsonParser.clean_response(text)

        start = text.find("{")

        if start == -1:
            raise ValueError("JSON start '{' not found.")

        brace_count = 0

        for index in range(start, len(text)):

            if text[index] == "{":
                brace_count += 1

            elif text[index] == "}":
                brace_count -= 1

                if brace_count == 0:
                    return text[start:index + 1]

        raise ValueError("Incomplete JSON object.")

    @staticmethod
    def parse(text: str) -> Dict[str, Any]:
        """
        Returns parsed JSON dictionary.
        """

        json_text = JsonParser.extract_json(text)

        try:
            return json.loads(json_text)

        except json.JSONDecodeError as e:

            logger.exception("JSON decoding failed.")

            raise ValueError(
                f"Invalid JSON returned by model: {e}"
            )

    @staticmethod
    def safe_parse(text: str) -> Dict[str, Any]:
        """
        Safe JSON parser.
        Returns default response on failure.
        """

        try:

            return JsonParser.parse(text)

        except Exception as e:

            logger.exception(e)

            result = default_response()

            result["business_reason"] = (
                f"JSON parsing failed : {str(e)}"
            )

            return result
        

# ==============================================================================
# Validator
# ==============================================================================

class Validator:
    """
    Validates and normalizes LLM output.
    """

    @staticmethod
    def normalize_text(value: Any) -> str:

        if value is None:
            return ""

        return str(value).strip()

    @staticmethod
    def normalize_boolean(value: Any) -> bool:

        if isinstance(value, bool):
            return value

        if isinstance(value, str):

            value = value.strip().lower()

            return value in {
                "true",
                "yes",
                "1",
                "y"
            }

        return bool(value)

    @staticmethod
    def normalize_integer(
        value: Any,
        minimum: int = 1,
        maximum: int = 10
    ) -> int:

        try:

            value = int(value)

        except Exception:

            value = minimum

        value = max(minimum, min(maximum, value))

        return value

    @staticmethod
    def normalize_trade(value: Any) -> str:

        value = Validator.normalize_text(value).lower()

        if value in VALID_TRADES:
            return value

        return "none"

    @staticmethod
    def normalize_service_category(value: Any) -> str:

        value = Validator.normalize_text(value).lower()

        aliases = {

            "service": "repair",

            "repair service": "repair",

            "diagnostic": "repair",

            "diagnosis": "repair",

            "install": "installation",

            "replace": "replacement",

            "maintenance visit": "maintenance",

            "tune up": "tune-up",

            "tuneup": "tune-up",

            "air quality": "iaq",

            "indoor air quality": "iaq",

            "waterheater": "water heater",

            "drain cleaning": "drain"

        }

        value = aliases.get(value, value)

        if value in VALID_SERVICE_CATEGORIES:
            return value

        return "none"

    @staticmethod
    def normalize_urgency(value: Any) -> str:

        value = Validator.normalize_text(value).lower()

        aliases = {

            "urgent": "same_day",

            "today": "same_day",

            "immediate": "emergency",

            "asap": "same_day",

            "normal": "routine"

        }

        value = aliases.get(value, value)

        if value in VALID_URGENCY:
            return value

        return "none"

    @staticmethod
    def normalize_appointment(value: Any) -> str:

        value = Validator.normalize_text(value).lower()

        aliases = {

            "booked": "scheduled",

            "booking": "requested",

            "appointment requested": "requested",

            "appointment scheduled": "scheduled",

            "not booked": "not_scheduled",

            "none": "not_scheduled"

        }

        value = aliases.get(value, value)

        if value in VALID_APPOINTMENT_STATUS:
            return value

        return "not_scheduled"

    @staticmethod
    def normalize_confidence(value: Any) -> str:

        value = Validator.normalize_text(value).lower()

        if value in VALID_CONFIDENCE:
            return value

        return "low"

    @staticmethod
    def normalize_evidence(value: Any) -> List[str]:

        if value is None:
            return []

        if isinstance(value, list):

            return [
                str(x).strip()
                for x in value
                if str(x).strip()
            ]

        if isinstance(value, str):

            value = value.strip()

            if value:

                return [value]

        return []

    @staticmethod
    def validate(result: Dict[str, Any]) -> Dict[str, Any]:

        output = default_response()

        output["core_intent"] = Validator.normalize_text(
            result.get("core_intent")
        )

        output["customer_problem"] = Validator.normalize_text(
            result.get("customer_problem")
        )

        output["customer_goal"] = Validator.normalize_text(
            result.get("customer_goal")
        )

        output["requested_service"] = Validator.normalize_text(
            result.get("requested_service")
        )

        output["trade"] = Validator.normalize_trade(
            result.get("trade")
        )

        output["service_category"] = Validator.normalize_service_category(
            result.get("service_category")
        )

        output["urgency"] = Validator.normalize_urgency(
            result.get("urgency")
        )

        output["appointment_status"] = Validator.normalize_appointment(
            result.get("appointment_status")
        )

        output["pricing_discussed"] = Validator.normalize_boolean(
            result.get("pricing_discussed")
        )

        output["intent_strength"] = Validator.normalize_integer(
            result.get("intent_strength"),
            minimum=1,
            maximum=10
        )

        output["confidence"] = Validator.normalize_confidence(
            result.get("confidence")
        )

        output["business_summary"] = Validator.normalize_text(
            result.get("business_summary")
        )

        output["business_reason"] = Validator.normalize_text(
            result.get("business_reason")
        )

        output["evidence"] = Validator.normalize_evidence(
            result.get("evidence")
        )

        return output
# ==============================================================================
# Business Rules
# ==============================================================================

class BusinessRules:
    """
    Applies business logic after validation.
    """

    @staticmethod
    def compute_revenue_opportunity(result: Dict[str, Any]) -> bool:

        # Customer explicitly requested a service
        if result["requested_service"]:
            return True

        # Customer intent is strong
        if result["intent_strength"] >= 6:
            return True

        # Valid trade identified
        if result["trade"] != "none":
            return True

        # Valid service category identified
        if result["service_category"] != "none":
            return True

        # Customer requested appointment
        if result["appointment_status"] in {
            "requested",
            "scheduled",
            "transferred"
        }:
            return True

        return False

    # ------------------------------------------------------------------

    @staticmethod
    def compute_confidence_score(result: Dict[str, Any]) -> int:

        score = 0

        if result["core_intent"]:
            score += 15

        if result["customer_problem"]:
            score += 15

        if result["customer_goal"]:
            score += 10

        if result["requested_service"]:
            score += 15

        if result["trade"] != "none":
            score += 10

        if result["service_category"] != "none":
            score += 10

        if result["appointment_status"] in {
            "requested",
            "scheduled",
            "transferred"
        }:
            score += 10

        if result["pricing_discussed"]:
            score += 5

        if result["evidence"]:
            score += 10

        score += result["intent_strength"]

        return min(score, 100)

    # ------------------------------------------------------------------

    @staticmethod
    def compute_confidence(score: int) -> str:

        if score >= 80:
            return "high"

        if score >= 55:
            return "medium"

        return "low"

    # ------------------------------------------------------------------

    @staticmethod
    def generate_business_summary(result: Dict[str, Any]) -> str:

        if result["business_summary"]:
            return result["business_summary"]

        summary = []

        if result["customer_problem"]:
            summary.append(result["customer_problem"])

        if result["requested_service"]:
            summary.append(
                f"Requested {result['requested_service']}"
            )

        elif result["service_category"] != "none":
            summary.append(
                f"Requested {result['service_category']} service"
            )

        if result["appointment_status"] in {
            "requested",
            "scheduled"
        }:
            summary.append("Appointment requested")

        return ". ".join(summary)

    # ------------------------------------------------------------------

    @staticmethod
    def generate_business_reason(result: Dict[str, Any]) -> str:

        if result["business_reason"]:
            return result["business_reason"]

        if result["revenue_opportunity"]:

            reasons = []

            if result["requested_service"]:
                reasons.append(
                    "Customer explicitly requested service."
                )

            if result["trade"] != "none":
                reasons.append(
                    f"Trade identified as {result['trade']}."
                )

            if result["service_category"] != "none":
                reasons.append(
                    f"Service category is {result['service_category']}."
                )

            if result["appointment_status"] in {
                "requested",
                "scheduled",
                "transferred"
            }:
                reasons.append(
                    "Customer attempted to schedule an appointment."
                )

            return " ".join(reasons)

        return (
            "Transcript does not contain sufficient evidence "
            "of a customer revenue opportunity."
        )

    # ------------------------------------------------------------------

    @staticmethod
    def apply(result: Dict[str, Any]) -> Dict[str, Any]:

        result["revenue_opportunity"] = (
            BusinessRules.compute_revenue_opportunity(result)
        )

        result["confidence_score"] = (
            BusinessRules.compute_confidence_score(result)
        )

        result["confidence"] = (
            BusinessRules.compute_confidence(
                result["confidence_score"]
            )
        )

        result["business_summary"] = (
            BusinessRules.generate_business_summary(result)
        )

        result["business_reason"] = (
            BusinessRules.generate_business_reason(result)
        )

        return result
    
# ==============================================================================
# Revenue Opportunity Analyzer
# ==============================================================================

class RevenueOpportunityAnalyzer:
    """
    Main detector pipeline.

    Pipeline
    --------
    Transcript
        ↓
    PromptManager
        ↓
    Claude
        ↓
    JSON Parser
        ↓
    Validator
        ↓
    Business Rules
        ↓
    Final Output
    """

    def __init__(self, llm: LLMClient):

        self.llm = llm

    # ------------------------------------------------------------------

    def analyze(
        self,
        transcript: str
    ) -> Dict[str, Any]:

        logger.info("=" * 80)
        logger.info("Revenue Opportunity Analysis Started")
        logger.info("=" * 80)

        if transcript is None:

            result = default_response()

            result["business_reason"] = "Transcript is None."

            return result

        transcript = str(transcript).strip()

        if not transcript:

            result = default_response()

            result["business_reason"] = "Transcript is empty."

            return result

        try:

            logger.info("Generating LLM response...")

            response = self.llm.generate(

                system_prompt=PromptManager.system_prompt(),

                user_prompt=PromptManager.user_prompt(transcript),

                temperature=0.0,

                max_tokens=1500

            )

            logger.info("LLM response received.")

        except Exception as e:

            logger.exception(e)

            result = default_response()

            result["business_reason"] = (
                f"LLM inference failed : {str(e)}"
            )

            return result

        # --------------------------------------------------------------
        # JSON Parsing
        # --------------------------------------------------------------

        logger.info("Parsing JSON response...")

        parsed = JsonParser.safe_parse(response)

        # --------------------------------------------------------------
        # Validation
        # --------------------------------------------------------------

        logger.info("Validating extracted fields...")

        validated = Validator.validate(parsed)

        # --------------------------------------------------------------
        # Business Rules
        # --------------------------------------------------------------

        logger.info("Applying business rules...")

        final_output = BusinessRules.apply(validated)

        logger.info("=" * 80)
        logger.info("Revenue Opportunity Analysis Completed")
        logger.info("=" * 80)

        return final_output

    # ------------------------------------------------------------------

    def __call__(
        self,
        transcript: str
    ) -> Dict[str, Any]:

        return self.analyze(transcript)
    
    # def create_detector(llm: LLMClient) -> RevenueOpportunityAnalyzer:
    #     """
    #     Factory method for creating the detector.
    #     """

    #     return RevenueOpportunityAnalyzer(llm)