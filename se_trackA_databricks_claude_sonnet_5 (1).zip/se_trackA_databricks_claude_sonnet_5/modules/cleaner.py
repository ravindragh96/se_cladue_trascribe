
# import re
# from typing import Optional

# class TranscriptCleaner:
#     def __init__(
#         self,
#         lowercase: bool = True,                # Changed to True
#         collapse_to_single_line: bool = True,  # Changed to True
#         remove_html: bool = True,
#         remove_extra_spaces: bool = True,
#         remove_blank_lines: bool = True,
#         normalize_quotes: bool = True,
#         clean_excel_artifacts: bool = True
#     ):
#         self.lowercase = lowercase
#         self.collapse_to_single_line = collapse_to_single_line
#         self.remove_html = remove_html
#         self.remove_extra_spaces = remove_extra_spaces
#         self.remove_blank_lines = remove_blank_lines
#         self.normalize_quotes = normalize_quotes
#         self.clean_excel_artifacts = clean_excel_artifacts

#     def clean(self, text: Optional[str]) -> str:
#         if text is None or (isinstance(text, float) and text != text): 
#             return ""

#         text = str(text)

#         # 1. Clean Hex-Encoding Artifacts
#         if self.clean_excel_artifacts:
#             text = re.sub(r"_x000[Dd]_", " ", text)
#             text = re.sub(r"_x000[Aa]_", " ", text)

#         # 2. Catch literal backslashes combined with 'n' or 'r' (e.g., "\\n")
#         text = text.replace("\\r\\n", " ")
#         text = text.replace("\\n", " ")
#         text = text.replace("\\r", " ")

#         # 3. Standardize real carriage returns
#         text = text.replace("\r", "\n")

#         # 4. Remove HTML tags
#         if self.remove_html:
#             text = re.sub(r"<.*?>", " ", text)

#         # 5. Flatten to a single line (Replace real newlines with spaces)
#         if self.collapse_to_single_line:
#             text = text.replace("\n", " ")
#         elif self.remove_blank_lines:
#             text = re.sub(r"\n\s*\n", "\n", text)

#         # 6. Normalize Spaces (This cleans up the mess left by replacing newlines with spaces)
#         if self.remove_extra_spaces:
#             text = re.sub(r"[ \t]+", " ", text)

#         # 7. Fix Punctuation Spacing (e.g., "see. hi" instead of "see.hi" or "see . hi")
#         text = re.sub(r"\s+([.,!?])", r"\1", text)
        
#         # 8. Normalize Quotes
#         if self.normalize_quotes:
#             text = text.replace("“", '"').replace("”", '"')
#             text = text.replace("’", "'").replace("‘", "'")

#         # 9. Convert to Lowercase
#         if self.lowercase:
#             text = text.lower()

#         return text.strip()
    

# # if __name__ == "__main__":

# #     sample = """
# #     Hi, thank you for calling Service Experts.

# #     I need someone to repair my AC.

# #     """

# #     cleaner = TranscriptCleaner()

# #     cleaned = cleaner.clean(sample)

# #     print(cleaned)


######################################################################################################################################################

# modules/cleaner.py
import re
from typing import Optional


class TranscriptCleaner:
    def __init__(
        self,
        lowercase: bool = False,
        collapse_to_single_line: bool = False,
        remove_html: bool = True,
        remove_extra_spaces: bool = True,
        remove_blank_lines: bool = True,
        normalize_quotes: bool = True,
        clean_excel_artifacts: bool = True
    ):
        self.lowercase = lowercase
        self.collapse_to_single_line = collapse_to_single_line
        self.remove_html = remove_html
        self.remove_extra_spaces = remove_extra_spaces
        self.remove_blank_lines = remove_blank_lines
        self.normalize_quotes = normalize_quotes
        self.clean_excel_artifacts = clean_excel_artifacts

    def clean(self, text: Optional[str]) -> str:
        if text is None or (isinstance(text, float) and text != text):
            return ""
        text = str(text)

        # 1. Clean Hex-Encoding Artifacts
        if self.clean_excel_artifacts:
            text = re.sub(r"_x000[Dd]_", " ", text)
            text = re.sub(r"_x000[Aa]_", " ", text)

        # 2. Catch literal backslashes combined with 'n' or 'r' (e.g., "\\n")
        text = text.replace("\\r\\n", " ")
        text = text.replace("\\n", " ")
        text = text.replace("\\r", " ")

        # 3. Standardize real carriage returns
        text = text.replace("\r", "\n")

        # 4. Remove HTML tags
        if self.remove_html:
            text = re.sub(r"<.*?>", " ", text)

        # 5. Preserve speaker-turn newlines so ConversationSplitter can segment
        #    on them (and its min_length filter can drop bare speaker labels
        #    like "Customer:"). Only flatten if explicitly requested.
        if self.collapse_to_single_line:
            text = text.replace("\n", " ")
        elif self.remove_blank_lines:
            text = re.sub(r"\n\s*\n", "\n", text)

        # 6. Normalize Spaces (cleans up the mess left by newline handling)
        if self.remove_extra_spaces:
            text = re.sub(r"[ \t]+", " ", text)

        # 7. Fix Punctuation Spacing (e.g., "see. hi" instead of "see.hi" or "see . hi")
        text = re.sub(r"\s+([.,!?])", r"\1", text)

        # 8. Normalize Quotes
        if self.normalize_quotes:
            text = text.replace("\u201c", '"').replace("\u201d", '"')
            text = text.replace("\u2019", "'").replace("\u2018", "'")

        # 9. Convert to Lowercase (off by default — preserves verbatim
        #    capitalization for evidence quotes; detector.py's own
        #    normalization methods already lowercase internally, so this
        #    isn't needed for intent/trade/urgency matching)
        if self.lowercase:
            text = text.lower()

        return text.strip()