"""
Conversation Splitter

Splits a customer service transcript into individual sentences/utterances
for semantic evidence retrieval.
"""

import re
from typing import List


class ConversationSplitter:

    def __init__(self, min_length: int = 10):
        self.min_length = min_length

    def process(self, transcript: str) -> List[str]:
        """Split transcript into meaningful sentences."""
        if not transcript or not transcript.strip():
            return []

        # Split on sentence boundaries
        sentences = re.split(
            r'(?<=[.!?])\s+|\n+',
            transcript.strip()
        )

        # Filter short/empty fragments
        results = []
        for s in sentences:
            s = s.strip()
            if len(s) >= self.min_length:
                results.append(s)

        return results
