import logging
import pandas as pd
import streamlit as st

# Replace with your actual project imports
from models.model_registry import ModelRegistry
from modules.cleaner import TranscriptCleaner
from modules.detector import RevenueOpportunityAnalyzer
from modules.evidence import EvidenceExtractor
from modules.llm_client import LLMClient

logger = logging.getLogger(__name__)

@st.cache_resource(show_spinner=False)
def initialize_pipeline():
    """Loads all AI models once and caches them across sessions."""
    logger.info("Initializing AI Pipeline...")
    registry = ModelRegistry()
    cleaner = TranscriptCleaner()
    llm_client = LLMClient(registry=registry)
    detector = RevenueOpportunityAnalyzer(llm=llm_client)
    evidence = EvidenceExtractor(registry=registry)
    
    return {
        "registry": registry,
        "cleaner": cleaner,
        "detector": detector,
        "evidence": evidence
    }

def process_transcript(transcript: str, pipeline: dict) -> dict:
    """Executes single transcript inference pipeline."""
    cleaner = pipeline["cleaner"]
    detector = pipeline["detector"]
    evidence = pipeline["evidence"]
    
    cleaned = cleaner.clean(transcript)
    intent_results = detector.analyze(cleaned)
    # return evidence.enrich(transcript=cleaned, analysis_result=analysis)
    evidence_results = evidence.extract(cleaned,intent_results)
    
    # Mock return structure for testing UI flow
    # return {
    #     "core_intent": "Schedule Maintenance",
    #     "customer_problem": "AC stopped cooling",
    #     "customer_goal": "Get technician out today",
    #     "requested_service": "AC Repair",
    #     "trade": "HVAC",
    #     "urgency": "High",
    #     "appointment_status": "Requested",
    #     "pricing_discussed": True,
    #     "revenue_opportunity": True,
    #     "intent_strength": 9,
    #     "confidence": "High",
    #     "confidence_score": 92,
    #     "business_summary": "Customer requested urgent AC repair service.",
    #     "business_reason": "High intent with clear equipment issue.",
    #     "evidence": ["AC stopped cooling yesterday"]
    # }
    return {
        "core_intent": intent_results.get(
        "core_intent", ""
        ),
        "customer_problem": intent_results.get(
        "customer_problem", ""
        ),
        "customer_goal": intent_results.get(
        "customer_goal", ""
        ),
        "requested_service": intent_results.get(
        "requested_service", ""
        ),
        "trade": intent_results.get(
        "trade", "none"
        ),
        "service_category": intent_results.get(
        "service_category", "none"
        ),
        "urgency": intent_results.get(
        "urgency", "none"
        ),
        "appointment_status": intent_results.get(
        "appointment_status",
        "Not Scheduled"
        ),
        "pricing_discussed": intent_results.get(
        "pricing_discussed",
        False
        ),
        "revenue_opportunity": intent_results.get(

        "revenue_opportunity",
      
        False
     
        ),
    
        "intent_strength": intent_results.get(
       
        "intent_strength",
        1
        ),
    
        "confidence": intent_results.get(
       
        "confidence",
      
        "low"
       
        ),
      
        "confidence_score": intent_results.get(
      
        "confidence_score",
        
        0
       
        ),
       
        "evidence": evidence_results,
        
        "business_summary": intent_results.get(
     
        "business_summary",
       
        ""
        
        ),
      
        "business_reason": intent_results.get(
      
        "business_reason",
       
        ""
  
        )
        
    }