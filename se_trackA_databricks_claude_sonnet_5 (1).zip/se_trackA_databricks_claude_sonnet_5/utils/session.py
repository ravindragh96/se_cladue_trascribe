import streamlit as st
import pandas as pd

DEFAULT_STATE = {
    'batch_results':None,
    'anamysis_results': None,
    'uploaded_df':None,
    'data_source':None,
    'run_complete':False
}
def init_session_state():
    "Initialize Streamlit session state variables"
    for key,value in DEFAULT_STATE.items():
        if key not in st.session_state:
            st.session_state[key] = value