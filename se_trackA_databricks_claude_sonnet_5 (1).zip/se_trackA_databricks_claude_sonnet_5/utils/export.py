import io
import pandas as pd

def dataframe_to_csv(df: pd.DataFrame) -> str:
    """Converts a pandas dataframe into a downloadable CSV string."""
    return df.to_csv(index=False)

def dataframe_to_excel(df: pd.DataFrame) -> bytes:
    """Converts a pandas dataframe into an Excel binary stream."""
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Revenue Opportunities")
    return output.getvalue()

def generate_audit_report_text(record: pd.Series) -> str:
    """Formats an individual record into a plain text audit document."""
    return f"""==================================================
SERVICE EXPERTS AI - AUDIT REPORT
==================================================
Call Identifier : {record.get('call_id', 'N/A')}
Trade Category  : {record.get('trade', 'N/A')}
Service         : {record.get('requested_service', 'N/A')}
Urgency Level   : {record.get('urgency', 'N/A')}
--------------------------------------------------
Revenue Opportunity : {record.get('revenue_opportunity', 'N/A')}
AI Confidence Score : {record.get('confidence_score', 'N/A')}%
Appointment Status  : {record.get('appointment_status', 'N/A')}

BUSINESS SUMMARY:
{record.get('business_summary', 'N/A')}

AI DECISION REASONING:
{record.get('business_reason', 'N/A')}