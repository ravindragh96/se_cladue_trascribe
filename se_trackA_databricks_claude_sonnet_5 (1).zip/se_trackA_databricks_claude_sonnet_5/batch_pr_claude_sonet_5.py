# Databricks notebook source
# MAGIC %pip install -r requirements.txt
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import pandas as pd

from models.model_registry import ModelRegistry
from modules.cleaner import TranscriptCleaner
from modules.llm_client import LLMClient
from modules.detector import RevenueOpportunityAnalyzer
from modules.evidence import EvidenceExtractor

# COMMAND ----------

# ==============================================================================
# Initialize Pipeline
# ==============================================================================

registry = ModelRegistry()

llm = LLMClient(registry)

cleaner = TranscriptCleaner()

detector = RevenueOpportunityAnalyzer(llm)

extractor = EvidenceExtractor(registry)

# COMMAND ----------

# ==============================================================================
# Process Single Transcript
# ==============================================================================

def process_transcript(transcript: str):

    cleaned = cleaner.clean(transcript)

    analysis = detector.analyze(cleaned)

    analysis = extractor.enrich(
        cleaned,
        analysis
    )

    return analysis

# COMMAND ----------

transcript = """
We'll see.
Hi, thank you for calling Service Experts. This is Joy. How may I help you?
Um, I just called previously about having a technician come out to look at our HVAC system because I keep smelling like, uh, alcohol antifreeze smell.
Um, in regards with your AC off of the moment, uh, you were smelling alcohol on it, correct?
Yeah, I keep smelling like the whole house smells like antifreeze almost and like alcohol.
OK, let's go ahead and, uh, check out the, uh, on call technician that I can, uh, dispatch tonight. Uh, would you mind to provide to me your service address down to the zip code please?
Um, it is, can you do a service tomorrow?
In regards to with the ma'am, uh, we cannot, um, guarantee the available appointment that we can offer to is actually on, um, January 2, 1st thing in the morning.
That's fine because we had the fire department come so they said we, our oxygen is good here.
OK, that's a good, uh, relief as well on that.
So I don't think it's a life-threatening, but I keep smelling.
The alcohol one
Hm?
Hello?
OK, um,
Hello, can you hear me?
Yes ma'am, I can hear you no better.
Hello?
Hello? Yes?
OK, can you hear me, ma'am?
Yes I can hear you.
OK, so as of the moment, um, you've mentioned that you've already talked to a fire department, correct?
Yes, ma'am.
OK, well, thank you, ma'am, and that's also a relief that death, uh, that the, uh, fire department you've already talked about, but no worries, let's go ahead and check uh the availability of our technician. Would you mind to provide to me your service address down to zip code?
[ADDRESS]
And that's [ORIGIN] [NUMERICAL_PII].
Thank you so much for this one, ma'am. I will be checking the uh availability on February 2, OK?
OK
OK, give me a second.
I would like to confirm ma'am, if this is the first time you, uh, we do the service on your home.
Yes,
I see, OK, and uh would you mind to provide to me your first and last name please?
[NAME_MEDICAL_PROFESSIONAL].
Thank you so much. So the spell of the [NAME_MEDICAL_PROFESSIONAL] is gonna be T R O I, correct?
Yes
OK, and the number that you are using to call us right now that ends with 883-4 is the number that we our technician can call you, correct?
Yes
OK thank you so much and I just want also to confirm um if um it happens if you do have an email address so that in a future appointment you have the um appointment um.
Notification
Do I have the notification or are you sending me a notification?
Oh yes, we were going to send you a notification that's why I'm, uh, I will, I've been needing the uh ser um the email address rather.
Oh, T R O I P I T T at [EMAIL_ADDRESS].
OK.
Thank you so much for this one, ma'am. I do apologize uh for this one, but I do really need the uh your uh confirmation again with your service address.
Hm?
I, I need, um, um, I do apologize, I, I do need you to repeat uh the service address please.
Huh?
29
02.
T R A R I C H Rd.
OK
OK, let me go ahead now and create the account for you.
And this is the residential and you are the owner correct?
No, I'm not the owner.
My grandmother's the owner.
OK, you are the pennant?
OK, thank you so much for this one.
Yes.
So let me go ahead now and check out the earliest one on um Feb January 2.
OK, thank you so much, Will, for waiting on the line. On January 2, I don't have an available, but on January 3 between 8 to 12 p.m. window arrival if this is OK with you.
Perfect.
OK, so let's go ahead and secure this appointment and do you have special instruction for our technician before the arrival like there's a dog in your house or there's a gate code or need to be a leather?
No, they're fine.
OK, and I would like also to confirm if where is your system located at your home?
I can just walk up.
Under the house
Is it a crawl space?
Yeah.
OK
OK, in regards with this one, there is a diagnostic charge amounting to [NUMERICAL_PII] and the society repairs will be discussed by our technician, OK.
OK, so it's [NUMERICAL_PII] for a diagnosis?
Yes it is ma'am, and the society repairs will be discussed by the technician if there's bars needed to be uh replaced or some, um, it depends.
Uh, they will be diagnosing that one.
OK, and then.
How would, um, wait, so they would have to diagnose each component too?
They will be checking every, um,
In that specific system that we had a problem.
OK
OK, so just a quick recap of the appointment that you were scheduled on January 3 between 8 to 12 p.m. in the arrival. Confirmation email will be coming soon and we will going to call you before the arrival. Aside from this one, is there anything else that I can help you with?
That's fine. I just wanna confirm it's [NUMERICAL_PII] for the diagnostic, and then what was that extra fee you were talking about?
It depends on the technician diagnostic on the system whether needed to be replaced a new parts or needed to be estimate uh some um parts on it then they will be at um discussing it to you if you agree with that one, then they will go ahead and process and if it's not, then only the diagnostic charge about about the um problem.
Mhm.
OK.
And they'll process it when they come in, or do you guys bill me?
Our technicians have the authority as well to process the payment. You can uh pay them by cash or uh a card they can assist you with that one as well.
OK perfect.
OK, so is there anything else aside from this one, ma'am?
No thank you.
OK, well thank you so much for calling EEB Service Experts. You do have a great day. Bye for now and happy New Year.
You too.
Happy New Year. Thank you.
Thank you, bye bye.
Bye.
.




"""




# COMMAND ----------

result = process_transcript(transcript)
display(result)

# COMMAND ----------

# ==============================================================================
# Batch Processing
# ==============================================================================

def process_dataframe(df):

    results = []

    for _, row in df.iterrows():

        transcript = str(
            row["transcription_text"]
        )

        output = process_transcript(
            transcript
        )

        results.append(output)

    output_df = pd.concat(
        [
            df.reset_index(drop=True),
            pd.DataFrame(results)
        ],
        axis=1
    )

    return output_df

# COMMAND ----------

# import io
# import pandas as pd 

# file_path = "/Volumes/dev/se_demo_trans/transcripts/Contact_Center_Transcripts.xlsx"
# binary_df = spark.read.format("binaryFile").load(file_path)
# content = binary_df.collect()[0]["content"]

# !pip install openpyxl
import io
import pandas as pd

file_path = "/Volumes/dev/se_demo_trans/transcripts/Contact_Center_Transcripts.xlsx"
binary_df = spark.read.format("binaryFile").load(file_path)
content = binary_df.collect()[0]["content"]

df = pd.read_excel(io.BytesIO(content), engine='openpyxl')

df.head()

# COMMAND ----------

# results = []
# total = len(df)
# for i, (_, row) in enumerate(df.iterrows(), 1):
#     print(f"Processing transcript {i}/{total}...")
#     transcript = str(row["transcription_text"])
#     output = process_transcript(transcript)
#     results.append(output)

# print(f"Completed processing {total} transcripts.")

# output_df = pd.concat(
#     [df.reset_index(drop=True), pd.DataFrame(results)],
#     axis=1
# )
# display(output_df)

# COMMAND ----------

output_file = "/Volumes/dev/se_demo_trans/transcripts/Contact_Center_Transcripts_results_claude_sonnet.json"

# COMMAND ----------

from tqdm import tqdm
import os 
import json
import re
import time
def run_batch_analysis(
    dataframe: pd.DataFrame,
    output_json_path: str,
    batch_size: int = 25
):
    """
    Run transcript analysis on entire dataframe.

    Parameters
    ----------
    dataframe : pd.DataFrame
    output_json_path : str
    batch_size : int

    Returns
    -------
    pd.DataFrame
    """

    results = []

    total = len(dataframe)

    print(f"Processing {total} transcripts...")

    for start in range(0, total, batch_size):

        end = min(start + batch_size, total)

        batch = dataframe.iloc[start:end]

        print(f"\nBatch {start//batch_size + 1} ({start}-{end-1})")

        for index, row in tqdm(batch.iterrows(), total=len(batch)):

            call_id = row.get("call_id", f"Unknown_{index}")
            raw_transcript = row.get("transcription_text", "")

            if not isinstance(raw_transcript, str):
                continue

            if raw_transcript.strip() == "":
                continue

            # --- Source identifiers for downstream joins ---
            source_ids = {
                "from_number": row.get("from_number", None),
                "to_number": row.get("to_number", None),
                "call_date_utc": str(row.get("call_date_utc", "")),
                "agent_id": row.get("agent_id", None),
                "agent_name": row.get("agent_name", None),
                "queue_name": row.get("queue_name", None),
                "audio_transcript_id": row.get("audio_transcript_id", None),
            }

            try:

                # -----------------------------------------
                # Clean Transcript
                # -----------------------------------------
                cleaned_text = cleaner.clean(raw_transcript)

                # -----------------------------------------
                # Detect Business Intent
                # -----------------------------------------
                intent_results = detector.analyze(cleaned_text)

                # -----------------------------------------
                # Semantic Evidence
                # -----------------------------------------
                evidence_results = extractor.extract(
                    cleaned_text,
                    intent_results,
                    top_k=3
                )

                results.append({

                    "call_id": call_id,

                    **source_ids,

                    "core_intent":
                        intent_results.get("core_intent", ""),

                    "customer_problem":
                        intent_results.get("customer_problem", ""),

                    "customer_goal":
                        intent_results.get("customer_goal", ""),

                    "requested_service":
                        intent_results.get("requested_service", ""),

                    "trade":
                        intent_results.get("trade", "none"),

                    "service_category":
                        intent_results.get("service_category", "none"),

                    "urgency":
                        intent_results.get("urgency", "none"),

                    "appointment_status":
                        intent_results.get(
                            "appointment_status",
                            "Not Scheduled"
                        ),

                    "pricing_discussed":
                        intent_results.get(
                            "pricing_discussed",
                            False
                        ),

                    "revenue_opportunity":
                        intent_results.get(
                            "revenue_opportunity",
                            False
                        ),

                    "intent_strength":
                        intent_results.get(
                            "intent_strength",
                            1
                        ),

                    "confidence":
                        intent_results.get(
                            "confidence",
                            "low"
                        ),

                    "confidence_score":
                        intent_results.get(
                            "confidence_score",
                            0
                        ),

                    "evidence": evidence_results,

                    "business_summary":
                        intent_results.get(
                            "business_summary",
                            ""
                        ),

                    "business_reason":
                        intent_results.get(
                            "business_reason",
                            ""
                        ),

                    "status": "Success"

                })

            except Exception as e:

                print(f"Error in Call ID {call_id}: {e}")

                results.append({

                    "call_id": call_id,

                    **source_ids,

                    "status": "Failed",

                    "error_message": str(e)

                })

    # --------------------------------------------------------
    # Save JSON
    # --------------------------------------------------------

    os.makedirs(os.path.dirname(output_json_path), exist_ok=True)

    with open(output_json_path, "w") as f:
        json.dump(results, f, indent=4)

    print(f"\nResults saved to:\n{output_json_path}")

    return pd.DataFrame(results)

# COMMAND ----------

results = run_batch_analysis(df,output_json_path=output_file, batch_size= 20)

# COMMAND ----------

display(results)

# COMMAND ----------

# DBTITLE 1,Save results to Delta table for dashboard
# Save results to a Delta table for the AI/BI dashboard
results_for_table = results.drop(columns=["evidence"], errors="ignore")

spark_df = spark.createDataFrame(results_for_table)
spark_df.write.mode("overwrite").saveAsTable("dev.se_demo_trans.transcript_analysis_claude_sonnet")

print("Table saved: dev.se_demo_trans.transcript_analysis_claude_sonnet")
print(f"Rows: {spark_df.count()}")