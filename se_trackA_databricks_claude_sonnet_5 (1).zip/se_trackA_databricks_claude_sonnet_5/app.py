import streamlit as st

# Custom Utilities and Pipeline Functions
from utils.session import init_session_state
from pipeline.inference import initialize_pipeline
from components.sidebar import render_sidebar

# Clean Modular Page Handlers
from pages.transcript import render_transcript_page
from pages.batch import render_batch_page
from pages.dashboard import render_dashboard_page
from pages.opportunities import render_opportunity_page
from pages.executive import render_executive_page
from pages.audit import render_audit_page


def main():
    st.set_page_config(
        page_title="Service Experts AI",
        page_icon="📞",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    # 1. Initialize Global Session State
    init_session_state()

    # 2. Render Sidebar Navigation (responds to health check immediately)
    selected_page = render_sidebar()

    # 3. Lazy-load AI pipeline only when needed (avoids startup timeout)
    def get_pipeline():
        if "pipeline" not in st.session_state:
            with st.spinner("Loading AI models... (first run only)"):
                st.session_state.pipeline = initialize_pipeline()
        return st.session_state.pipeline

    # 4. Dynamic Page Routing
    if selected_page == "🏠 Home":
        st.title("🏠 Service Experts AI Platform")
        st.markdown("""
        ### Welcome to the Call Intelligence Hub
        Select an operational view from the left sidebar navigation menu:
        * **📝 Single Transcript:** Perform ad-hoc model inference on custom call transcripts.
        * **📂 Batch Processing:** Upload bulk audio transcripts (CSV/Excel/Databricks) for batch analysis.
        * **📊 Analytics Dashboard:** Review aggregated revenue opportunities, customer problems, and trade distributions.
        * **💼 Opportunity Intelligence:** Monitor conversation conversion funnels and automated CSR recommendations.
        * **🧠 Executive Command Center:** Assess overall business health scoring and high-level KPI trends.
        * **🔍 Audit Center:** Deep dive into AI predictions, supporting quotes, and confidence scores.
        """)

    elif selected_page == "📝 Single Transcript":
        render_transcript_page(get_pipeline())

    elif selected_page == "📂 Batch Processing":
        render_batch_page(get_pipeline())

    elif selected_page == "📊 Analytics Dashboard":
        render_dashboard_page()

    elif selected_page == "💼 Opportunity Intelligence":
        render_opportunity_page()

    elif selected_page == "🧠 Executive Command Center":
        render_executive_page()

    elif selected_page == "🔍 Audit Center":
        render_audit_page()


if __name__ == "__main__":
    main()